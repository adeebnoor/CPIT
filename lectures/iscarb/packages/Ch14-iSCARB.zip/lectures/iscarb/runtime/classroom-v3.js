/* iSCARB shared classroom runtime. Authored hints are not AI grading.
 * Source availability, draft completeness, self-report and assessed competence
 * are deliberately different states. No responses are sent to a server.
 */
(()=>{'use strict';
const D=JSON.parse(document.getElementById('lecture-data').textContent),$=s=>document.querySelector(s),qa=s=>Array.from(document.querySelectorAll(s));
if(D.presentationMode==='single-canvas')document.body.classList.add('single-canvas');
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const key=`iscarb:classroom:ch${D.chapter}:v3`,validField=k=>/^[a-z][a-z0-9_]{0,59}$/.test(k)&&!['constructor','prototype','__proto__'].includes(k);
// Story v3 + stage v4: one narrative series, act structure and in-class engagement over the same 20 slides.
const SERIES=window.ISCARB_STORY||null,STORY=SERIES?.chapters?.[D.chapter]||null;
if(STORY)document.documentElement.dataset.stage='v4';
const ACTS=(D.roadmap?.branches||[]).map((b,i)=>{const at=(b.units||[]).map(u=>D.slides.findIndex(s=>s.id===u)).filter(n=>n>=0);return {b,i,first:Math.min(...at),last:Math.max(...at)};}).filter(a=>Number.isFinite(a.first));
const TWIST_AT=D.stations?.[2]?.at;
setInterval(()=>{const c=document.querySelector('.pace-chip');if(c&&PLAN)c.outerHTML=paceChip();},20000);
let savedOK=true,state={fields:{},seen:[],quiz:{},ai:{},self:{},votes:{},gut:{},theme:'night'},index=0,stationMode=false,voteMode=null,voteStage=0,quizIndex=0,returnFocus=null;
try{const s=JSON.parse(localStorage.getItem(key)||'null');if(s&&s.schema==='iscarb-classroom-v3'&&s.chapter===D.chapter){state={...state,...sanitize(s).state};}}catch(e){savedOK=false;}
let remaining=180,deadline=0,ticker=null,nationalIndex=null;
// Presenter mode (Faculty-Presenter.html or ?presenter=1) shows instructor notes; students do not see them.
const PRESENTER=(()=>{try{const q=new URLSearchParams(location.search);if(q.has('presenter'))sessionStorage.setItem('iscarb-presenter',q.get('presenter')==='0'?'0':'1');return sessionStorage.getItem('iscarb-presenter')==='1';}catch(e){return /[?&]presenter=1\b/.test(location.search);}})();
if(PRESENTER)document.body.classList.add('presenter');
// Pace v1: a 50-minute plan is the presenter default (&pace=60 or &pace=full to change). It chooses which
// class votes and stations fit, and shows the planned finish minute for each slide against elapsed time.
const PACE=(()=>{if(!PRESENTER||!STORY)return null;let p='50';try{const q=new URLSearchParams(location.search).get('pace');if(q)sessionStorage.setItem('iscarb-pace',q);p=sessionStorage.getItem('iscarb-pace')||'50';}catch(e){}return ['50','60','full'].includes(p)?p:'50';})();
function buildPlan(B){
 const fixed={TITLE:3,MAP:1,START:2,END:3},voteActs=[1,3].filter(i=>i<ACTS.length),stationNos=B>=60?[2]:[],extra=D.slides.map(()=>0);
 const tw=D.slides.findIndex(s=>s.id===TWIST_AT);if(tw>=0)extra[tw]+=3;
 voteActs.forEach(a=>{extra[ACTS[a].last]+=4;});
 D.stations.filter(st=>stationNos.includes(st.no)).forEach(st=>{const i=D.slides.findIndex(s=>s.id===st.at);if(i>=0)extra[i]+=5;});
 const regular=D.slides.filter(s=>!fixed[s.id]).length,used=Object.values(fixed).reduce((a,b)=>a+b,0)+extra.reduce((a,b)=>a+b,0),per=Math.max(1,(B-used)/regular);
 let t=0;const end=D.slides.map((s,i)=>t+=fixed[s.id]??(per+extra[i]));
 return {B,voteActs,stationNos,end,per};
}
const PLAN=PACE&&PACE!=='full'?buildPlan(Number(PACE)):null;
const paceKey='iscarb-pace-start-ch'+D.chapter;
function paceStart(){try{return Number(sessionStorage.getItem(paceKey))||0;}catch(e){return 0;}}
function paceHelp(){return `<tr><th>Lesson pace</th><td>${PLAN?`${PLAN.B}-minute plan: class votes after acts ${PLAN.voteActs.map(i=>i+1).join(' and ')}; stations ${PLAN.stationNos.length?PLAN.stationNos.join(', ')+' planned, others':'are'} optional. Add &amp;pace=60 or &amp;pace=full to the address to change.`:'Full plan: every vote and station. Add &amp;pace=50 for the 50-minute plan.'} The chip beside the slide number shows when this slide should end; click it to restart the clock from here.</td></tr>`;}
function paceChip(){
 if(!PLAN)return '';
 const start=paceStart(),plannedFrom=index?PLAN.end[index-1]:0,plannedTo=PLAN.end[index];
 let state='',label='Clock starts when you leave the cover';
 if(start){const el=(Date.now()-start)/60000,d=Math.round(el-plannedFrom);label=`${Math.floor(el)} min elapsed`;state=d>=3?'behind':d<=-3?'ahead':'on';label+=state==='behind'?` · ${d} min behind`:state==='ahead'?` · ${-d} min ahead`:' · on time';}
 return `<button class="pace-chip ${state}" data-pace-reset title="Planned finish for this slide, ${PLAN.B}-minute plan. Click to restart the clock.">⏱ finish by min ${Math.round(plannedTo)} / ${PLAN.B} · ${label}</button>`;
}
const quizOrder={};
function shuffledIndexes(n,i){if(!quizOrder[i]){const a=[...Array(n).keys()];for(let k=n-1;k>0;k--){const j=Math.floor(Math.random()*(k+1));[a[k],a[j]]=[a[j],a[k]];}quizOrder[i]=a;}return quizOrder[i];}
function installNELCShortcut(){const top=document.querySelector('.topnav');if(!top||document.getElementById('nelcBtn'))return;top.insertAdjacentHTML('beforeend','<button id="readinessBtn" class="nelc-shortcut" data-open="READINESS">Jaheziah readiness</button><button id="nelcBtn" class="nelc-shortcut" data-open="NELC" title="Saudi national AI-supported learning design alignment">NELC alignment</button>');}
installNELCShortcut();
const profileLink='<a class="lecture-profile" href="https://adeebnoor.github.io/">About &amp; contact ↗</a>';
$('.footer-left').insertAdjacentHTML('beforeend',profileLink);
const labels={claim:'CLAIM',evidence:'EVIDENCE',warrant:'WARRANT',uncertainty:'UNCERTAINTY',counter:'COUNTER-EVIDENCE',verdict:'VERDICT',owner:'DECISION OWNER',reviewer:'EVIDENCE REVIEWER',signoff:'SIGN-OFF ROLE',initial:'INITIAL DECISION',revision:'REVISED DECISION',ai_disclosure:'AI DISCLOSURE / INDEPENDENT CHECK',constraint:'CONSTRAINT',derive:'DERIVE',principle:'NAME THE PRINCIPLE',prediction:'PREDICT',known:'KNOWN',unknown:'UNKNOWN',monitor:'MONITOR',architecture:'ARCHITECTURE / IMPLEMENTATION',practice:'CONTEMPORARY PRACTICE',workload:'WORKLOAD / HANDOVER',local_context:'LOCAL CONTEXT / AUTHORITY',evidence_gap:'EVIDENCE GAP',self_level:'SELF-PLACEMENT / REASON'};
function pack(){return {schema:'iscarb-classroom-v3',chapter:D.chapter,release:D.release,exportedAt:new Date().toISOString(),state};}
function save(){try{localStorage.setItem(key,JSON.stringify(pack()));savedOK=true;}catch(e){savedOK=false;}qa('[data-save-status]').forEach(e=>e.textContent=savedOK?'Draft saved on this device · not submitted or graded':'Local saving unavailable · export a backup before leaving');}
function field(k,label,ph='',value){return `<label class="field"><span>${esc(label||labels[k]||k)}</span><textarea data-field="${esc(k)}" maxlength="15000" placeholder="${esc(ph)}">${esc(value??state.fields[k]??'')}</textarea></label>`;}
function button(label,open,cls=''){return `<button class="${cls}" data-open="${esc(open)}">${esc(label)}</button>`;}
function jumpButton(k,label){return `<button data-jump="${esc(k)}">${esc(label||titleOf(k))}</button>`;}
function titleOf(k){return D.slides.find(s=>s.id===k)?.title||({RULES:'20-rule map',CARD:'Decision card',READING:'Required source review',QUIZ:'Five-objective practice',READINESS:'NCAAA / Jaheziah',NELC:'NELC alignment',RUBRIC:'Four-level rubric',HSTACK:'H-Stack',PREDICT:'Prediction',MONITOR:'Known / Unknown / Monitor',AI:'AI gate',PORTFOLIO:'Portfolio and assignment',EVIDENCE:'Evidence policy',LOCAL:'Saudi context',PRACTICE:'Contemporary practice',WELLBEING:'Practitioner wellbeing',BRIDGE:'Implementation annotation'}[k]||k);}
function sourceLink(s,label='Open source detail'){let a=s.sourceStart||firstNumber(s.sourceRange)||1;return `<a href="sources/Ch${D.chapter}-Study.html#source-slide-${a}" target="_blank" rel="noopener">${esc(label)}</a>`;}
function firstNumber(s){return Number(String(s||'').match(/\d+/)?.[0]||1);}
function ref(s){return s.sourceLabel|| (s.sourceRange?`Sommerville Ch.${D.chapter} · source slides ${s.sourceRange}`:'Course example · fictional case');}
function points(ps){return `<ul class="points">${(ps||[]).map(p=>`<li><strong>${esc(p[0])}.</strong> ${esc(p[1])}</li>`).join('')}</ul>`;}
function table(v){return `<table class="table-main"><thead><tr>${(v.heads||['CONCEPT','MEANING']).map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${v.rows.map(r=>`<tr>${r.map((x,i)=>`<${i?'td':'th'}${i?'':' scope="row"'}>${esc(x)}</${i?'td':'th'}>`).join('')}</tr>`).join('')}</tbody></table>`;}
function classroomRedraw(s){
 const items=(s.nodes?.length?s.nodes:(s.bullets||[]).map(p=>[p[0],p[1]||''])).filter(Boolean).slice(0,5);
 if(!items.length)return '';
 const cls='redraw-count-'+Math.min(items.length,5);
 return `<div class="figure-button classroom-redraw-wrap">
  <div class="classroom-redraw ${cls}" role="img" aria-label="Projection-safe redesign of ${esc(s.title)}">
   <span class="redraw-kicker">PROJECTION-SAFE REDESIGN · SOURCE-GROUNDED</span>
   <span class="redraw-title">${esc(s.title)}</span>
   <span class="redraw-flow">
    ${items.map((n,i)=>`<span class="redraw-node"><i>${i+1}</i><b>${esc(n[0])}</b>${n[1]?`<small>${esc(n[1])}</small>`:''}</span>`).join('')}
   </span>
   <span class="redraw-source-note">Redrawn for classroom legibility; meaning remains anchored to the preserved source figure.</span>
   <button class="redraw-open" type="button" data-image="${esc(s.figure)}" data-caption="${esc(s.caption||s.title)}" aria-label="Open preserved original source figure: ${esc(s.title)}">View preserved original · native resolution ↗</button>
  </div>
 </div><p class="caption">${esc(s.caption||'Resolution-independent classroom redesign · preserved source available at native resolution')}</p>`;
}
function sourceVector(s){const entry=window.ISCARB_SOURCE_FIGURES?.[s.figure];if(!entry)return '';return `<div class="source-vector-panel">${entry.variants.length>1?`<div class="vector-tabs" aria-label="Source figures">${entry.variants.map((v,i)=>`<button data-vector-tab="${i}" aria-pressed="${i===0}">Source ${v.sourceSlide}${i===0?' · activities':' · planning'}</button>`).join('')}</div>`:''}${entry.variants.map((v,i)=>`<button class="figure-button source-vector" data-vector-pane="${i}" ${i?'hidden':''} data-image="${esc(v.src)}?v=20260928-campus-v3" data-caption="${esc(s.title)} · original source slide ${v.sourceSlide}" data-vector="1" aria-label="Enlarge original vector figure: ${esc(s.title)}"><img src="${esc(v.src)}?v=20260928-campus-v3" alt="${esc(s.title)} · original diagram from source slide ${v.sourceSlide}" decoding="async"></button>`).join('')}<p class="caption">Original source diagram · vector quality · select to enlarge</p></div>`;}
// When a slide has no figure, table or comparison, its cards and its bullet list said the same thing twice
// (often as label-only cards). Merge them: one card per idea, label plus meaning.
function mergedCards(s){
 if(s.rows||s.visual?.rows||s.approaches||s.figure||s.banner)return '';
 const bullets=(s.bullets||[]).filter(b=>Array.isArray(b)&&b[0]);if(!bullets.length)return '';
 const norm=t=>String(t||'').toLowerCase().replace(/^\s*\d+\s*·\s*/,'').replace(/[^a-z0-9]+/g,' ').trim();
 const nodes=s.nodes||[];
 if(nodes.length){const labels=new Set(bullets.map(b=>norm(b[0])));if(!nodes.every(n=>labels.has(norm(n[0]))))return '';}
 const numbered=nodes.length&&/^\s*\d+\s*·/.test(nodes[0][0]);
 return `<ul class="concepts merged" style="--cards:${Math.min(bullets.length,5)}">${bullets.map((b,i)=>`<li class="concept"><b>${numbered?`${i+1} · `:''}${esc(b[0])}</b><span>${esc(b[1]||'')}</span></li>`).join('')}</ul>`;
}
function visual(s){if(s.rows)return table(s);if(s.visual?.rows)return table(s.visual);if(s.approaches)return `<div class="two-approaches">${s.approaches.map(a=>`<section class="approach"><h2 class="approach-label">${esc(a.label)}</h2><p>${esc(a.title||'')}</p><div class="arrow-chain">${(a.nodes||[]).map(n=>`<span>${esc(n)}</span>`).join('')}</div><p>${esc(a.text||'')}</p></section>`).join('')}</div>`;
if(s.figure&&window.ISCARB_SOURCE_FIGURES?.[s.figure])return sourceVector(s);
if(s.figure){if(/\.(?:png|jpe?g|webp)(?:$|[?#])/i.test(s.figure))return classroomRedraw(s);return `<button class="figure-button" data-image="${esc(s.figure)}" data-caption="${esc(s.caption||s.title)}" aria-label="Enlarge figure: ${esc(s.title)}"><img src="${esc(s.figure)}" alt="${esc(s.caption||s.title)}" decoding="async"></button><p class="caption">${esc(s.caption||'Original source figure · select to enlarge')}</p>`;}
let ns=s.nodes?.length?s.nodes:(s.bullets||[]).slice(0,3).map(p=>[p[0],'']);return `<div class="concepts ${s.flow?'flow':''}">${ns.map(n=>`<div class="concept"><b>${esc(n[0])}</b>${n[1]?`<span>${esc(n[1])}</span>`:''}</div>`).join('')}</div>`;}
// Readable presentation sections preserve all authored content and the 20-slide sequence.
let sectionIndex=0,sectionNodes=[];
function readingLayout(){return document.body.classList.contains('reading')||matchMedia('(max-width:1000px), (max-height:620px)').matches;}
function sectionNode(label,nodes){const e=document.createElement('section');e.className='lecture-section';e.dataset.sectionLabel=label;e.setAttribute('aria-label',label);nodes.filter(Boolean).forEach(n=>e.append(n));return e;}
function buildReadable(s){
 const main=$('#chapter-main');sectionIndex=0;sectionNodes=[];
 const heading=main.querySelector('.heading');if(!heading||stationMode)return;
 if(D.presentationMode==='single-canvas'){main.classList.add('single-canvas-slide');return;}
 const get=sel=>main.querySelector(sel),groups=[];
 const add=(label,nodes)=>{const live=nodes.filter(Boolean);if(live.length)groups.push(sectionNode(label,live));};
 if(s.id==='TITLE'){add('Start here',[get('.hero'),get('.scope-note')]);}
 else if(s.id==='MAP'){
  const cases=document.createElement('div');cases.className='map-connections';
  main.querySelectorAll('.map-step').forEach(step=>{const c=document.createElement('section');c.className='connection-card';const title=document.createElement('h3');title.textContent=step.querySelector('strong').textContent;c.append(title);step.querySelectorAll('.step-case,.step-lens').forEach(n=>c.append(n));cases.append(c);});
  const storyContext=get('.map-question p');
  if(storyContext)storyContext.remove();
  add('Concept map',[get('.map-question'),get('.concept-path'),get('.mind-link')]);
  add('Your chapter tasks',[get('.student-roadmap'),get('.map-bottom')]);
  add('Story connections',[storyContext,cases]);
 }else if(s.id==='START'){
  const situation=get('.story-grid section');
  if(situation)situation.classList.add('story-situation');
  add('The scenario',[get('.story-head'),situation]);
  add('Your decision',[get('.story-grid')]);
  add('AI context & route',[get('.story-lens'),get('.story-route'),get('.story-note'),get('.story-action')]);
 }else if(s.id==='END'){
  const hero=get('.end-hero'),copy=get('.end-copy');
  const tasks=document.createElement('div');tasks.className='closing-tasks';
  copy.querySelectorAll('.end-required,.end-boundary,.end-disclosure,.actions').forEach(n=>tasks.append(n));
  add('What you can now do',[hero]);add('Finish the chapter',[tasks]);
 }else{
  const v=get('.visual'),meaning=get('.meaning'),tableEl=v?.querySelector('table');
  if(tableEl&&tableEl.tBodies[0].rows.length>4){
   const rows=[...tableEl.tBodies[0].rows];
   for(let i=0;i<rows.length;i+=3){const wrap=document.createElement('div');wrap.className='visual';const tableCopy=tableEl.cloneNode(true);tableCopy.tBodies[0].replaceChildren(...rows.slice(i,i+3));wrap.append(tableCopy);const takeaway=get('.takeaway');add('Explore '+(i/3+1),[takeaway?.cloneNode(true),wrap]);}
  }else add('Explore',[get('.takeaway'),v]);
  if(meaning?.querySelector('.points li'))add('Understand',[meaning]);
  add('Apply & discuss',[get('.case-thread'),get('.ai-banner'),get('.ai-lens'),get('.question')]);
 }
 // Keep unclassified authored blocks visible rather than dropping them.
 const remaining=[...main.children].filter(n=>n!==heading&&!groups.includes(n)&&!n.matches('.body-grid,.takeaway'));
 if(remaining.length)add('More',[...remaining]);
 [...main.children].filter(n=>n!==heading).forEach(n=>n.remove());
 const nav=document.createElement('nav');nav.className='section-tabs';nav.setAttribute('aria-label','Sections in this slide');
 const stage=document.createElement('div');stage.className='lecture-stage';
 groups.forEach((g,i)=>{g.id='lecture-section-'+i;stage.append(g);const b=document.createElement('button');b.dataset.slideSection=i;b.textContent=g.dataset.sectionLabel;b.setAttribute('aria-controls',g.id);nav.append(b);});
 if(groups.length>1)main.append(nav);main.append(stage);sectionNodes=groups;showSection(0,false);
 // Overflow is an explicit readable fallback, never a smaller font or clipped text.
 requestAnimationFrame(()=>{if(sectionNodes===groups)checkSectionFit();});
}
function showSection(n,focus=false){
 if(n<0||n>=sectionNodes.length)return;sectionIndex=n;
 const reading=readingLayout();sectionNodes.forEach((s,i)=>{s.hidden=!reading&&i!==n;});
 qa('[data-slide-section]').forEach(b=>{const on=+b.dataset.slideSection===n;b.setAttribute('aria-pressed',String(on));b.classList.toggle('active',on);});
 $('#prevBtn').disabled=index===0&&n===0;$('#nextBtn').disabled=index===D.slides.length-1&&n===sectionNodes.length-1;
 $('#prevBtn').title=n?'Previous section':'Previous slide';$('#nextBtn').title=n<sectionNodes.length-1?'Next section':'Next slide';
 $('#live').textContent=`Slide ${index+1} of ${D.slides.length}: ${D.slides[index].title}. ${sectionNodes[n].dataset.sectionLabel}, section ${n+1} of ${sectionNodes.length}.`;
 if(focus){sectionNodes[n].setAttribute('tabindex','-1');sectionNodes[n].focus({preventScroll:true});}
 checkSectionFit();
}
function checkSectionFit(){
 const stage=$('.lecture-stage');if(!stage||readingLayout())return;
 const current=sectionNodes[sectionIndex];if(!current)return;
 const footer=$('.footerbar').getBoundingClientRect();
 const overflow=current.scrollHeight>stage.clientHeight+2||[...current.querySelectorAll('p,li,td,th,img,button')].some(e=>e.getBoundingClientRect().bottom>footer.top-8);
 stage.classList.toggle('needs-scroll',overflow);
}
function advanceSection(delta){
 if(voteMode!==null){if(delta>0&&voteStage<3){voteStage++;render();return;}voteMode=null;voteStage=0;if(delta>0&&index<D.slides.length-1)go(index+1);else render();return;}
 if(delta>0&&nextBuild())return;
 if(nationalIndex!==null){const n=nationalIndex+delta;if(n>=0&&n<2)nationalSlide(n);else go(index);return;}
 if(!stationMode&&!readingLayout()&&sectionNodes.length){const n=sectionIndex+delta;if(n>=0&&n<sectionNodes.length){showSection(n);return;}}
 go(index+delta);
 if(delta<0&&!readingLayout()&&sectionNodes.length)showSection(sectionNodes.length-1);
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-slide-section]');if(b){showSection(+b.dataset.slideSection);if(readingLayout())sectionNodes[sectionIndex].scrollIntoView({behavior:'smooth',block:'start'});}});
let layoutFrame;window.addEventListener('resize',()=>{cancelAnimationFrame(layoutFrame);layoutFrame=requestAnimationFrame(()=>{if(sectionNodes.length)showSection(sectionIndex);});});

function nationalSlide(n){
 closeModal();pauseTimer();stationMode=false;sectionNodes=[];nationalIndex=n;
 const c=window.ISCARB_NATIONAL.chapters[D.chapter],isReady=n===0;
 const title=isReady?'Jaheziah: what can you demonstrate?':'NELC: how we design your learning';
 $('#chapter-main').className='chapter-main national-slide';
 $('#chapter-main').innerHTML=`<div class="heading"><div><p class="ey">SAUDI ALIGNMENT · CHAPTER ${D.chapter} · ${esc(D.title)}</p><h1 lang="en" dir="ltr">${title}</h1></div><span class="counter">${n+1} / 2 · reference</span></div>
 <section class="national-canvas" lang="en" dir="ltr" aria-label="${title}">
 <div class="national-brand"><div class="national-logo"><img src="assets/national/${isReady?'etec-logo.svg':'nelc-logo.png'}" alt="${isReady?'Education and Training Evaluation Commission':'National eLearning Center'}"></div><div><p class="national-kicker">${isReady?'Jaheziah · Learning outcomes':'AI-supported Teaching and Learning Design Framework'}</p><h2>${isReady?'Knowledge → skills → responsibility':'Learning first. Human judgment at the center.'}</h2></div></div>
 ${isReady?`<div class="national-readiness"><article><span>01 · Knowledge</span><h3>${esc(c.knowledge)}</h3></article><article><span>02 · Skills</span><h3>${esc(c.skill)}</h3></article><article><span>03 · Values</span><h3>${esc(c.value)}</h3></article></div><p class="national-evidence"><b>Your chapter evidence</b><span>${esc(c.evidence)}</span></p>`:`<div class="national-principles">${window.ISCARB_NATIONAL.principles.map((p,i)=>`<div><span>0${i+1}</span><b>${esc(p)}</b></div>`).join('')}</div><div class="national-roles"><span><b>Learner</b> explains and verifies</span><span><b>AI</b> suggests alternatives</span><span><b>Instructor</b> reviews and judges</span></div><div class="national-cycle" aria-label="Six framework stages">${window.ISCARB_NATIONAL.stages.map((p,i)=>`<span><i>${i+1}</i>${esc(p)}</span>`).join('')}</div>`}
 </section>
 <div class="national-actions"><button data-open="${isReady?'READINESSDETAIL':'NELCDETAIL'}">${isReady?'Objectives & evidence':'Alignment & evidence'}</button><button data-open="${isReady?'QUIZ':'AI'}">${isReady?'Check your understanding':'AI-use boundaries'}</button><button data-national-return>Return to lecture</button></div>
 <p class="national-scope" lang="en" dir="ltr">${isReady?'Proposed educational mapping; official codes require program approval.':'Aligned to the September 2026 framework; this is not certification or partnership.'} The logo identifies the reference organization.</p>`;
 $('#prevBtn').disabled=false;$('#nextBtn').disabled=false;
 $('#topic-location').textContent=isReady?'Jaheziah · readiness':'NELC · learning design';
 $('#progress').textContent='2 reference slides · classroom sequence stays 20';
 $('#live').textContent=title;
 history.replaceState(null,'','#NATIONAL-'+(isReady?'JAHEZIAH':'NELC'));
}
function render(){nationalIndex=null;clearInterval(thinkTimer);thinkTimer=null;const s=D.slides[index],stop=D.stations.find(x=>x.at===s.id);$('#chapter-main').className='chapter-main'+(s.fullTable?' full-table':'')+(s.skin?' skin-'+String(s.skin).replace(/[^a-z0-9-]/gi,''):'');$('#chapter-main').dataset.act=String((actOf(s)?.i??-1)+1);
$('#chapter-main').innerHTML=`<div class="heading"><div><p class="ey">${esc(stationMode?'CLASSROOM STATION':s.phase||'LEARN')} · CHAPTER ${D.chapter}</p><h1>${esc(s.id==='TITLE'?(STORY?STORY.episode:'A decision you can explain'):s.id==='MAP'?'Chapter mind map':s.id==='START'?(STORY?'The case file':'The story we will solve'):s.id==='END'?(STORY?'Episode close · readiness':'Readiness & next step'):s.title)}</h1></div><span class="counter">${index+1} / ${D.slides.length}</span>${paceChip()}</div>`;
if(stationMode&&stop){renderStation(stop);updateNav();return;}
if(voteMode!==null&&D.quiz?.[voteMode]){$('#chapter-main .heading .ey').textContent='CLASS VOTE · CHAPTER '+D.chapter;renderVote(voteMode);updateNav();return;}
if(s.id==='TITLE'&&STORY){$('#chapter-main').classList.add('cold-open-page');$('#chapter-main').insertAdjacentHTML('beforeend',`<div class="hero cold-open"><div><p class="ey">CHAPTER ${D.chapter} · ${esc(D.title)} · ${esc(SERIES.series)}</p><h2>${esc(D.title)}</h2><p class="cold-scene">${esc(STORY.coldOpen)}</p><div class="cold-meta"><span class="clock">⏱ ${esc(STORY.clock)}</span>${D.hook?`<span class="hero-hook"><i class="ai-tag">AI</i>${esc(D.hook)}</span>`:''}</div><div class="actions">${jumpButton('MAP','See the chapter map →')}${D.aiAssignment?button('AI challenge','AIASSIGN','ai-cta'):''}${button('Resume draft','CARD')}</div><p class="small"><a href="https://adeebnoor.github.io/">Professor Adeeb Noor ↗</a> · King Abdulaziz University · fictional teaching case</p></div><img src="${esc(D.brand)}" alt=""></div>${gutBlock('before')}`);}
else if(s.id==='TITLE'){$('#chapter-main').insertAdjacentHTML('beforeend',`<div class="hero"><div><p class="ey">iSCARB · CPIT-455</p><h2>${esc(D.title)}</h2><p>${esc(D.case.headline)}</p><div class="route-tags"><span>SEE</span><span>EXPLAIN</span><span>TEST</span><span>DECIDE</span></div>${D.hook?`<p class="hero-hook"><i class="ai-tag">AI</i><span>${esc(D.hook)}</span></p>`:''}<p class="small"><a href="https://adeebnoor.github.io/">Professor Adeeb Noor ↗</a> · King Abdulaziz University${D.hook?'':`<br>${D.slides.length} classroom slides · five objectives · one evolving artifact`}</p><div class="actions">${jumpButton('MAP','See the chapter map →')}${D.aiAssignment?button('AI challenge','AIASSIGN','ai-cta'):''}${button('Resume draft','CARD')}</div></div><img src="${esc(D.brand)}" alt=""></div><p class="scope-note">Required: the class slides and the named source review. The extra tools are optional unless your instructor assigns them.</p>`);}
else if(s.id==='MAP'){renderMindMap();}
else if(s.id==='START'){renderStory();}
else if(s.id==='END'){renderClosing();}
else{const merged=mergedCards(s),twist=twistBlock(s);if(twist)$('#chapter-main').classList.add('twist-locked');$('#chapter-main').insertAdjacentHTML('beforeend',`${s.banner?bannerBlock(s):storyThread(s)}<p class="takeaway">${esc(s.takeaway||s.title)}${s.aiTag?AI_TAG:''}</p>${twist}${merged?`<div class="body-grid body-merged ${STORY?layoutFor(s):''}">${merged}</div>`:`<div class="body-grid"><div class="visual">${visual(s)}</div><div class="meaning"><h2>WHAT IT MEANS</h2>${points(s.bullets)}</div></div>`}${lensStrip(s)}${yourCall(s,stop)}`);}
updateNav();buildReadable(s);setupBuilds();}
function updateNav(){$('#prevBtn').disabled=index===0;$('#nextBtn').disabled=index===D.slides.length-1;$('#progress').innerHTML=`${new Set(state.seen).size} / ${D.slides.length} visited<span class="nav-shortcuts">Enter → · Backspace ←</span>`;$('#live').textContent=`Slide ${index+1} of ${D.slides.length}: ${D.slides[index].title}`;updateMapLocation();save();}
function go(n,history=true){if(!Number.isInteger(n)||n<0||n>=D.slides.length)return;if(PLAN&&n>0&&!paceStart())try{sessionStorage.setItem(paceKey,String(Date.now()-PLAN.end[0]*60000));}catch(e){}pauseTimer();stationMode=false;voteMode=null;voteStage=0;if(n!==index)buildSlide=-1;index=n;if(!state.seen.includes(D.slides[index].id))state.seen.push(D.slides[index].id);render();if(history)try{window.history.replaceState(null,'','#'+D.slides[index].id);}catch(e){}if(matchMedia('(max-width:1000px)').matches)window.scrollTo(0,0);}
function jump(k){const aliases=D.aliases||{};k=aliases[k]||k;let n=D.slides.findIndex(s=>s.id===k);closeModal();if(n>=0)go(n);else open(k);}
function modal(title,html){pauseTimer();returnFocus=document.activeElement;$('#modal-title').textContent=title;$('#modal-body').innerHTML=html;$('#modal').hidden=false;$('#modal-close').focus();save();}
function closeModal(){if($('#modal').hidden)return;$('#modal').hidden=true;$('#modal-body').innerHTML='';if(returnFocus?.isConnected)returnFocus.focus();}
function full(k){const s=D.slides.find(x=>x.id===k);if(!s)return;modal('Full explanation · '+s.title,`<div class="callout">${esc(ref(s))}. Source detail remains required; the short classroom bullets do not replace it.</div>${s.full||`<p>${esc(s.explanation||'')}</p>`}${s.extra?`<p>${esc(s.extra)}</p>`:''}<h3>Source and qualifications</h3><p>${sourceLink(s,'Read the original explanation, examples and caveats')}</p><p class="small">Textbook examples are historical. The course scenarios are fictional, and proposed tests are not measured results.</p>`);}
function answer(k){const s=D.slides.find(x=>x.id===k);if(!s)return;const inline=$('#chapter-main .inline-answer'),btn=$('#chapter-main [data-answer]');if(inline&&D.slides[index].id===k){inline.hidden=!inline.hidden;btn?.setAttribute('aria-expanded',String(!inline.hidden));if(btn)btn.textContent=inline.hidden?'Reveal answer':'Hide answer';buildItems.forEach(e=>e.classList.add('built'));buildAt=buildItems.length;return;}modal('Model answer · attempt first',`<p>${esc(s.question)}</p><div class="callout">${esc(s.answer||'A defensible response identifies the mechanism, states its assumptions and names evidence that could support or defeat it.')}</div><p class="small">An illustrative response, not the only acceptable wording or an automatic grade. The assessed assignment uses its own case and commit/reveal sequence.</p>${sourceLink(s)}`);}
function renderStation(st){remaining=st.seconds||180;$('#chapter-main').insertAdjacentHTML('beforeend',`<div class="station"><div class="station-top"><div><p class="ey">STATION ${st.no} / 3 · THE SAME DECISION CARD</p><h2>${esc(st.title)}</h2></div><div class="timer"><output id="timer-output" class="timer-output">03:00</output><button id="timer-start">Start</button><button id="timer-reset">Reset</button></div></div><div class="station-steps"><div><b>THINK · 30 SECONDS${aiTag(st,'think')}</b>${esc(st.think)}</div><div><b>PAIR · 60 SECONDS${aiTag(st,'pair')}</b>${esc(st.pair)}</div><div><b>WRITE · 90 SECONDS${aiTag(st,'write')}</b>${esc(st.write)}</div></div><div class="station-fields">${st.fields.map(k=>field(k,labels[k],st.prompts?.[k]||'Use facts, a source concept or a clearly labelled proposed check.')).join('')}</div><div class="hint-box" id="coach">${esc('Authored coach: attempt first. Label evidence as supplied, derived, proposed or executed; name who owns/reviews the decision; state what would change the verdict.')}</div><div class="actions"><button id="hintBtn" data-no="${st.no}">Hint before the answer</button><button id="station-answer" data-no="${st.no}">Discuss a possible answer</button>${button('Whole card / export','CARD')}<button id="station-back">Return to explanation</button></div><p class="scope-note">${esc(st.note||'Use the same artifact. Discuss reasoning; do not award a level from field length or a timer.')} <span data-save-status></span></p></div>`);timerLabel();}
function timerLabel(){const o=$('#timer-output');if(!o)return;o.textContent=String(Math.floor(remaining/60)).padStart(2,'0')+':'+String(remaining%60).padStart(2,'0');$('.timer')?.classList.toggle('over',remaining===0);$('#timer-start').textContent=ticker?'Pause':remaining===0?'Restart':'Start';}
function pauseTimer(){if(ticker){remaining=Math.max(0,Math.ceil((deadline-Date.now())/1000));clearInterval(ticker);ticker=null;}timerLabel();}
function startTimer(){if(ticker){pauseTimer();return;}if(remaining<=0)remaining=180;deadline=Date.now()+remaining*1000;ticker=setInterval(()=>{remaining=Math.max(0,Math.ceil((deadline-Date.now())/1000));timerLabel();if(!remaining){pauseTimer();$('#live').textContent='Station time complete. Finish the reasoning; this is not a grade.';}},250);timerLabel();}
function indexModal(){modal('20 classroom slides',`<div class="index-grid">${D.slides.map((s,i)=>`<button data-go="${i}" class="${i===index?'active':''}"><b>${String(i+1).padStart(2,'0')}</b><span>${esc(s.id==='MAP'?'Chapter mind map':s.title)}</span></button>`).join('')}</div>`);}
function reading(){modal('Required source review',`<div class="callout"><b>Classroom + named source detail are required.</b> The original source is preserved separately and loads only when opened. Finishing a chapter includes its named review, not only its main-slide count.</div><table><tr><th>Required selection</th><th>Original slide numbers</th><th>Action</th></tr>${D.readings.map(r=>`<tr><td>${esc(r.title)}</td><td>${esc(r.range)}</td><td><a href="sources/Ch${D.chapter}-Study.html#source-slide-${firstNumber(r.range)}" target="_blank" rel="noopener">Read selected source</a></td></tr>`).join('')}</table><h3>Observable work</h3><p>Explain how one named source concept changes or supports your artifact. Keep the source number, reasoning and limit together. A checkbox or a copied quotation alone is not enough.</p><div class="actions">${button('Five-objective practice','QUIZ')}${button('Source-to-lesson map','COVERAGE')}<a href="sources/Ch${D.chapter}-Study.html">All original slides and textbook reference</a></div><p class="small">Calendar deadlines and grade contributions remain in Blackboard. Toolkit extensions are optional unless assigned. Do not repeat an already completed submission under this edition.</p>`);}
function coverage(){modal('Source-to-lesson map',`<div class="callout">Which original source slides feed each lesson. Source slide numbers and textbook PDF pages are labelled separately.</div><table><tr><th>Original section</th><th>Source slides</th><th>Classroom locations</th></tr>${D.groups.map(g=>`<tr><td>${esc(g.title)}</td><td>${g.start}–${g.end}</td><td>${g.units.map(k=>jumpButton(k)).join(' ')}</td></tr>`).join('')}</table><p><a href="sources/Ch${D.chapter}-Study.html">Complete source ledger · ${D.sourceCount} original slides</a></p><p><a href="${esc(D.original)}" target="_blank" rel="noopener">Original supplied slide pack</a>${D.textbook?` · <a href="${esc(D.textbook)}" target="_blank" rel="noopener">Original textbook chapter · ${D.bookPages} PDF pages</a>`:''}</p><h3>Original figures</h3><p>The source ledger retains all original source text and links each diagram to its source pack. Preserved diagram assets are available in its figure gallery.</p>`);}
function rules(){modal('The 20 iSCARB rules · canonical map',`<div class="callout">The 20 rules behind every chapter, in their approved order. Each link shows where a rule appears in this lecture. The three stations build one decision card; the rules are not 20 extra tasks.</div><div class="rule-grid">${D.rules.map(r=>`<section class="rule-card" data-rule="${r.no}"><h3><b>${String(r.no).padStart(2,'0')}</b>${esc(r.title)}</h3><p>${esc(r.evidence)}</p><div class="actions">${r.targets.map(k=>button(titleOf(k),k)).join(' ')}</div></section>`).join('')}</div>`);}
function legacyTools(){modal('iSCARB toolkit',`<div class="callout">Use these tools to strengthen the same artifact. Only the classroom stations and named source review are required by default; extra tasks need an explicit instructor assignment.</div><div class="tool-grid">${['RULES','CARD','HSTACK','PREDICT','BRIDGE','MONITOR','LOCAL','PRACTICE','WELLBEING','AI','EVIDENCE','RUBRIC','READINESS','PORTFOLIO'].map(k=>button(titleOf(k),k)).join('')}${D.chapter===11?button('Metric calculator','CALCULATOR'):''}</div>`);}
function card(){modal('One decision card · classroom worksheet',`<div class="callout">Your work is saved locally when storage is available. Keep evidence status, decision boundary and human responsibility explicit: supplied/derived/proposed/executed; owner/reviewer; what would change the verdict. No cloud sync, grade, LMS submission or operational approval occurs here. The assessed case is separate.</div><div class="two-col">${['claim','evidence','warrant','counter','uncertainty','verdict'].map(k=>field(k,labels[k])).join('')}</div><h3>Revision and responsibility</h3>${field('initial')}${field('revision')}<div class="two-col">${['owner','reviewer','signoff','ai_disclosure'].map(k=>field(k,labels[k])).join('')}</div><div class="actions"><button data-export="json">Export backup · JSON</button><button data-export="md">Export readable card</button><button id="import">Import backup</button><button id="copy">Copy card</button><button id="clear">Clear classroom draft</button></div><p class="status" data-save-status></p><p class="small">Earlier lecture drafts have not been erased. <a href="previous-lectures/Ch${D.chapter}-Previous-Lecture.html" target="_blank" rel="noopener">Open the previous lecture to recover its local draft</a>. Assignment drafts and locked Part A are untouched by this worksheet.</p>`);}
function hstack(){const names=['Analyze','Judge','Evidence','System','Risk','Ethics'];const texts=['Separate the concepts and trace the mechanism.','Compare alternatives under stated constraints.','Connect the claim to a source or inspectable result.','Follow interfaces, dependencies and operating context.','State uncertainty, counter-evidence and fallback.','Disclose assistance and name human responsibility.'];modal('Six H-Stack capabilities',`<p>The approved course capability vocabulary—not a national classification or an automatic score.</p><table><tr><th>Capability</th><th>Visible in your chapter artifact</th></tr>${names.map((x,i)=>`<tr><th>${x}</th><td>${texts[i]}</td></tr>`).join('')}</table>${button('Review the card','CARD')}`);}
function predict(){modal('Predict → Constraint → Derive → Name',`<div class="callout">${esc(D.case.text)}</div>${field('initial','INITIAL DECISION','Your tentative decision before the explanation.')}${field('prediction')}${field('constraint','CONSTRAINT','What operating condition limits this answer?')}${field('derive','DERIVE','Why does the mechanism support your prediction? Show units if calculating.')}${field('principle','NAME','Name the source concept you used.')}<p class="small">Keep the original view and write later changes under revision. This is reflective practice, not a secure assessment lock.</p>`);}
function bridge(){modal('Architecture / implementation structure',`<p>${esc(D.bridge)}</p>${field('architecture','IMPLEMENTATION ANNOTATION','Input / component / interface → decision or transformation → output / fallback. Name one shared dependency.')}${field('evidence_gap','VERIFICATION ARTIFACT','The actual or proposed test, model, table or trace that checks this implementation.')}<div class="actions">${jumpButton(D.mechanism,'Return to the chapter mechanism')}${button('Evidence policy','EVIDENCE')}</div>`);}
function monitor(){modal('Known / Unknown / Monitor',`${field('known','KNOWN','Only supplied source/case facts and derived calculations.')}${field('unknown','UNKNOWN','The missing condition, dependency or unexecuted check.')}${field('monitor','MONITOR','Quantity or event + window + proposed/approved trigger + owner + action.')}<p class="small">A proposed threshold is not an observed result or an approved operating limit.</p>`);}
function local(){modal('Saudi-aligned engineering context',`<p>This is a fictional teaching context, not a description of a live KAU system. Identify the actual service owner, affected users, language/access needs and authority before applying the argument to a real organization.</p>${field('local_context','LOCAL CONSTRAINT → EVIDENCE → EFFECT','Which institutional document, version or owner establishes this constraint? How would it change the chapter artifact?')}${field('owner')}${field('signoff')}<p class="small">No regulatory approval, national compliance or official mapping is inferred from a Saudi setting.</p>`);}
function practice(){modal('Trend / contemporary practice',`<p>Connect a source mechanism to a tool or workflow you have actually used. This is an evidence-seeking exercise, not a claim that the textbook’s historical examples are the latest standard.</p>${field('practice','CURRENT PRACTICE → SOURCE → VERSIONED ARTIFACT',D.practice)}<p class="small">Name the tool/version and authoritative documentation date. Keep an untested suggestion labelled proposed.</p>`);}
function wellbeing(){modal('Practitioner wellbeing as a system variable',`<p>${esc(D.workload)}</p>${field('workload','WORKLOAD / HANDOVER → DESIGN CHANGE → CHECK','Identify an operator burden, a feasible change and evidence that would evaluate it.')}<p class="small">The course exercise treats workload as a design variable; it does not diagnose a person or claim a measured wellbeing effect.</p>`);}
function aiVerdict(a){if(a[0]===undefined)return 'Record whether the output enters the evidence chain.';if(a[0]==='no')return 'Preparation only: check factual claims and disclose assistance; do not file generated text as verified evidence.';if(a[3]==='no')return 'Not permitted as assurance evidence: named human review is missing.';if(a[1]==='no'&&a[2]==='no')return 'Not permitted as assurance evidence: neither independent re-derivation nor testing is available.';if(a[3]!=='yes')return 'Incomplete: identify the responsible human review.';if(a[1]==='yes')return 'Conditionally permitted under the course policy: retain the independent derivation and named review.';if(a[2]==='yes')return 'Conditionally permitted: retain the independently executed test and its result, not the generated answer alone.';return 'Incomplete: establish an independent checking route.';}
function ai(){const qs=['Will this output enter the evidence chain?','Can its relevant result be independently re-derived?','Can its relevant claim be independently tested?','Is a named human responsible for review and sign-off?'];modal('Critical AI literacy · permissibility gate',`<p>Use only authorized, non-sensitive teaching inputs. No AI service is called by this page.</p>${qs.map((q,i)=>`<div class="ai-row"><span>${i+1}. ${esc(q)}</span>${['yes','no'].map(v=>`<button data-ai="${i}" data-value="${v}" aria-pressed="${state.ai[i]===v}">${v==='yes'?'Yes':'No'}</button>`).join('')}</div>`).join('')}<div id="ai-result" class="result" role="status">${esc(aiVerdict(state.ai))}</div>${field('ai_disclosure','ASSISTANCE + INDEPENDENT CHECK + HUMAN OWNER','No AI used, or describe the assistance, check and review.')}`);}
function evidence(){modal('Evidence policy / proof of capability',`<table><tr><th>Evidence type</th><th>Required honest record</th></tr><tr><td>Source explanation</td><td>Exact source/slide/page, relevant meaning and limitations.</td></tr><tr><td>Fictional case input</td><td>Label as supplied teaching data—not live operational measurement.</td></tr><tr><td>Derived result</td><td>Inputs, method/formula, units, independent arithmetic and scope.</td></tr><tr><td>Proposed test</td><td>Unexecuted plan, expected result, owner and conditions.</td></tr><tr><td>Executed test</td><td>Actual version, inputs, date, log, outcome and reviewer.</td></tr><tr><td>AI assistance</td><td>Disclosure and independent verification; not authority by itself.</td></tr></table><p>Opening pages is not learning evidence by itself. Field completeness is not correctness. A plan is not a passed test.</p>${field('evidence_gap')}`);}
function rubric(){const rows=[['L1 · Asserting','Names a decision but lacks sufficient mechanism or inspectable support.'],['L2 · Reasoning','Explains a relevant mechanism and source concept; major evidence remains missing.'],['L3 · Justifying','Provides a checkable artifact, counter-evidence and explicit assumptions/limits.'],['L4 · Accountable','Defends a revision under the changed constraint and names review and decision responsibility.']];modal('Four-level capability rubric',`<table><tr><th>Level</th><th>What a reviewer examines</th></tr>${rows.map(r=>`<tr><th>${r[0]}</th><td>${r[1]}</td></tr>`).join('')}</table>${field('self_level','PROVISIONAL SELF-PLACEMENT + REASON','Use the descriptor and identify the next evidence gap.')}<p class="small">Descriptors support human review. The assignment retains its published raw-point rubric; no grade or level is awarded automatically by this lecture.</p>`);}
function readiness(){const c=window.ISCARB_NATIONAL.chapters[D.chapter];modal('Jaheziah · Chapter '+D.chapter,`<div class="callout" lang="en" dir="ltr"><b>Chapter evidence:</b> ${esc(c.evidence)}<br><b>What does the instructor review?</b> ${esc(c.check)}</div><div class="callout warning"><b>Required practice; official mapping is not asserted.</b> The supplied sources do not establish an approved program mapping for these authored chapter objectives. Exact national codes, exam weights and attainment are not invented.</div><table><tr><th>Chapter objective</th><th>Practice evidence</th><th>Assignment field / opportunity</th></tr>${D.objectives.map((o,i)=>`<tr><td><b>Objective ${D.chapter}.${i+1}</b> ${esc(o)}</td><td>${esc(D.alignment[i].evidence)}</td><td>${esc(D.alignment[i].field)}</td></tr>`).join('')}</table><p>Candidate domains are knowledge, skills, and values/responsibility. The program must approve the formal crosswalk. These opportunities do not mean one multiple-choice item certifies an outcome.</p><div class="actions">${button('Five-objective practice','QUIZ')}${button('Four-level rubric','RUBRIC')}${button('Card','CARD')}</div>`);}
function portfolio(){modal('One portfolio artifact · transfer to the assignment',`<p>${esc(D.artifact)}</p><ol><li>Explain the chapter-specific concept using the named source.</li><li>Build the requested technical artifact; do not invent executed tests.</li><li>State counter-evidence, uncertainty and a bounded decision.</li><li>Retain the initial view and justify a revision when the constraint changes.</li></ol><div class="callout">The three classroom stations feed one practice card. The separate assignment keeps its own case, existing ${D.points}-point rubric, commit/reveal sequence and Blackboard deadline. Do not add another full report merely to satisfy the 20 rules.</div><div class="actions"><a href="https://adeebnoor.github.io/CPIT/fbr-submission.html?chapter=${D.chapter}">Open Assignment ${D.assignment}</a>${button('Card / export','CARD')}${button('Outcome crosswalk','READINESS')}</div>`);}
function quiz(){const q=D.quiz[quizIndex],r=state.quiz[quizIndex]||{};modal(`Five-objective practice · Objective ${D.chapter}.${quizIndex+1}`,`<div class="quiz-dots">${D.quiz.map((_,i)=>`<button data-quiz="${i}" class="${i===quizIndex?'active':''}">${i+1}</button>`).join('')}</div><p><b>${esc(q.q)}</b></p><div class="quiz-options">${shuffledIndexes(q.options.length,quizIndex).map(i=>`<label><input type="radio" name="quiz" value="${i}" ${r.answer===i?'checked':''}><span>${esc(q.options[i])}</span></label>`).join('')}</div><div class="actions" style="margin-top:16px"><button id="quiz-check" class="primary">Check after attempting</button><button data-quiz="${Math.min(4,quizIndex+1)}" ${quizIndex===4?'disabled':''}>Next objective</button></div><div id="quiz-feedback" role="status" hidden></div><p class="small" style="margin-top:15px">Practice questions written for this course. They are not graded and are not exam items.</p>`);if(r.checked)quizFeedback();}
function quizFeedback(){const r=state.quiz[quizIndex],q=D.quiz[quizIndex],b=$('#quiz-feedback');b.hidden=false;b.className='feedback'+(r?.answer===q.answer?'':' wrong');b.textContent=(r?.answer===q.answer?'Correct for this case. ':'Review this distinction. ')+q.why;}
function calculator(){modal('Reliability metric calculator · observed ratios',`<div class="callout">Define the failure event and exposure. These are observed estimates, not a reliability certificate. The chapter’s reciprocal-rate convention for MTTF is used.</div><div class="two-col">${[['demands','Demands',10000],['failed','Failed demands',20],['events','Outage events',2],['time','Service window (hours)',1000],['down','Unavailable hours',1]].map(([k,l,v])=>`<label class="field"><span>${l}</span><input id="calc-${k}" type="number" min="0" step="any" value="${v}"></label>`).join('')}</div><button id="calculate">Calculate with units</button><div id="calc-result" class="result" role="status"></div><p class="small">Do not compare a rate per hour to a probability per demand without the relevant denominator. Zero observed events are not proof of infinite reliability.</p>`);compute();}
function compute(){const vs=['demands','failed','events','time','down'].map(k=>$('#calc-'+k)?.value);const b=$('#calc-result');if(vs.some(x=>x===undefined||x.trim()==='')){b.textContent='Enter every value; a blank is not zero.';return;}const [n,f,e,t,d]=vs.map(Number);if(![n,f,e,t,d].every(Number.isFinite)||n<=0||t<=0||f<0||f>n||e<0||d<0||d>t||![n,f,e].every(Number.isInteger)){b.textContent='Invalid observations: positive demand/window; whole non-negative counts; failed ≤ demands; downtime ≤ window.';return;}const fmt=n=>Number(n.toPrecision(8));b.innerHTML=`<p>POFOD estimate = ${f}/${n} = <b>${fmt(f/n)} per demand</b></p><p>ROCOF = ${e}/${t} = <b>${fmt(e/t)} outage events/hour</b></p><p>Reciprocal-rate MTTF = <b>${e?fmt(t/e)+' hours':'not estimable from zero observed events'}</b></p><p>AVAIL = (${t}−${d})/${t} = <b>${fmt(100*(t-d)/t)}%</b></p>`;}
function notes(){const s=D.slides[index];if(!PRESENTER){modal('Instructor notes','<p>Teaching notes are shown only in presenter mode, which your instructor uses in class.</p>');return;}modal('Instructor notes · '+s.title,`<p>${esc(s.notes||'Ask students to distinguish the source concept, the mechanism and its operating assumptions. Attempt before revealing; use the named source for detail rather than shrinking the main slide.')}</p><h3>Teaching move</h3><p>Use the three stations to develop one artifact. Sample reasoning orally. If a source topic is not finished, announce the precise required review rather than making it optional.</p><p>${esc(ref(s))}</p>${sourceLink(s)}`);}
function help(){modal('Navigation, sources and saving',`<p><a href="https://adeebnoor.github.io/">Professor Adeeb Noor · Profile, research &amp; contact ↗</a></p><p>Start at the cover, then the Chapter mind map on slide 2. Use Chapter map to return, Slides to jump, and Study &amp; tools for required review, your card, methodology and display settings.</p><table><tr><th>Enter / Backspace</th><td>Next / previous slide. On a focused button or link, Enter activates that control.</td></tr><tr><th>Mouse click / Shift + click</th><td>Next / previous slide when you click empty slide space in desktop presentation mode. Dragging to select text does not navigate.</td></tr><tr><th>← / →</th><td>Previous / next classroom slide.</td></tr><tr><th>Home / End</th><td>First / final slide.</td></tr><tr><th>O / C${PRESENTER?' / N':''}</th><td>Slide index / decision card${PRESENTER?' / instructor notes':''}.</td></tr><tr><th>Escape</th><td>Close a dialog; typing fields do not trigger navigation.</td></tr>${STORY&&PRESENTER?'<tr><th>Presenter · Enter</th><td>Reveals the next idea on the slide, then moves on. Class vote: Enter steps through vote → discuss → revote → reveal.</td></tr>'+paceHelp()+'<tr><th>Counting hands</th><td>Tap an option once per raised hand. Counts stay on this device and appear again at the episode close.</td></tr>':''}</table><p>Use Jaheziah and NELC for two full reference slides inside this lecture; Return or Escape restores the classroom slide. The same 20 scientific slides remain in their original order. Reading view and smaller screens show every section in order. Large tables continue in labelled sections; no font is shrunk to fit. Sources open separately on demand. Keep the accompanying runtime/assets folders when using an offline ZIP.</p><p>Classroom drafts are local. Export JSON to restore them, or Markdown to read them. The assessed assignment preserves its own identity, draft storage and commitment rules.</p><div class="actions">${button('Source coverage','COVERAGE')}${button('Export card','CARD')}</div>`);}
// Mind-map v1: source concepts and student workflow are distinct layers.
// This is an authored learning organizer, not an original textbook figure.
// Story v2: simpler concept path, one persistent case thread, and an explicit close.
function storyBranch(s){
 return D.roadmap?.branches?.find(x=>(x.units||[]).includes(s.id));
}
function bannerBlock(s){ const b=s.banner||{}; return `<figure class="ai-banner"><img src="${esc(b.src)}" alt="${esc(b.alt||'')}" decoding="async"><figcaption><span>${esc(b.label||'')}</span>${esc(b.caption||'')}</figcaption></figure>`; }
const AI_TAG='<i class="ai-tag" title="This part involves the AI component">AI</i>';
function aiTag(st,k){ return (st&&Array.isArray(st.ai)&&st.ai.includes(k))?AI_TAG:''; }
function lensStrip(s){ if(!s||!s.lens)return ''; return `<div class="ai-lens"><span>AI LENS</span><em>${esc(s.lens)}</em></div>`; }
function actOf(s){return ACTS.find(a=>(a.b.units||[]).includes(s.id))||null;}
function storyThread(s){
 if(['TITLE','MAP','START','END'].includes(s.id))return '';
 const a=actOf(s),b=a?.b,lens=b?.caseLens||D.case.question,n=a?a.i+1:0,i=D.slides.indexOf(s);
 const opening=!!(STORY&&a&&i===a.first&&STORY.acts?.[a.i]);
 const dots=STORY&&a?`<span class="act-dots" aria-hidden="true">${ACTS.map((x,k)=>`<i class="${k<a.i?'done':k===a.i?'on':''}"></i>`).join('')}</span>`:'';
 return `<div class="case-thread${opening?' act-open':''}"><span>CASE THREAD${n?` · ACT ${n} OF ${ACTS.length}`:''}</span><b>${esc(b?.label||D.case.headline)}</b><em>${esc(lens)}</em>${dots}</div>${opening?`<div class="act-scene"><span class="scene-who">${esc(SERIES.lead.name)}</span><p>${esc(STORY.acts[a.i])}</p></div>`:''}`;
}
// Layout follows the content, so consecutive slides do not all become four equal cards.
function layoutFor(s){const n=(s.bullets||[]).filter(b=>Array.isArray(b)&&b[0]).length,i=D.slides.indexOf(s);if(s.phase==='CHECK'&&n===3)return 'lay-flow lay-check';if(/^\s*\d+\s*·/.test(s.nodes?.[0]?.[0]||''))return n===4?'lay-quad':n===3?'lay-flow':'lay-trio';if(n<=2)return 'lay-split';if(n===3)return s.flow?'lay-flow':'lay-trio';if(n===4)return i%2?'lay-quad':'lay-steps';return 'lay-steps';}
function yourCall(s,stop){
 const a=actOf(s),vote=!!(STORY&&a&&D.slides.indexOf(s)===a.last&&D.quiz?.[a.i]&&(!PLAN||PLAN.voteActs.includes(a.i))),later=!!(PLAN&&stop&&!PLAN.stationNos.includes(stop.no));
 return `<div class="question your-call"><p class="question-text"><b>${STORY?'YOUR CALL':'BACK TO THE STORY'}</b>${esc(s.question||'Explain the concept using the teaching case.')}</p><div class="actions"><div class="buttons">${STORY?'<button class="think-btn" data-think="30">Think · 30 s</button>':''}<button data-answer="${esc(s.id)}" aria-expanded="false">${STORY?'Reveal answer':'Model answer'}</button><button data-full="${esc(s.id)}">Full explanation</button>${vote?`<button class="vote-btn" data-vote="${a.i}">Class vote · Act ${a.i+1}</button>`:''}${stop?`<button class="${later?'if-time':'primary'}" id="stationBtn">Station ${stop.no} · ${later?'if time allows':'build the card'}</button>`:''}</div><span class="source-line">${esc(ref(s))} · ${sourceLink(s)}</span></div>${STORY?`<div class="inline-answer" hidden><b>One defensible answer · after you have committed yours</b><p>${esc(s.answer||'A defensible response identifies the mechanism, states its assumptions and names evidence that could support or defeat it.')}</p><small>Illustrative, not the only acceptable wording or a grade.</small></div>`:''}</div>`;
}
// In-class COMMIT → STRESS: the changed condition stays covered until a decision is written down.
function twistBlock(s){
 if(!STORY||s.id!==TWIST_AT)return '';
 return `<div class="twist" data-twist-panel><div class="twist-commit"><span>COMMIT FIRST</span><p>Write your current decision in one sentence, on paper or in the decision card. Then see what ${esc(SERIES.lead.name)} finds.</p><button class="primary" data-twist-reveal>Reveal the new information</button></div><div class="twist-scene" hidden><span>NEW INFORMATION</span><p>${esc(STORY.twist)}</p></div></div>`;
}
function gutBlock(round){
 const g=STORY?.gut;if(!g)return '';
 const counts=state.gut[round]||g.options.map(()=>0),total=counts.reduce((x,y)=>x+y,0),before=state.gut.before;
 return `<div class="gut" data-gut-round="${round}"><p class="gut-q"><span>${round==='before'?'GUT CHECK · BEFORE ANY THEORY':'VOTE AGAIN · SAME QUESTION'}</span>${esc(g.q)}</p><div class="gut-options">${g.options.map((o,i)=>`<button class="gut-opt" data-gut="${round}" data-opt="${i}"><i>${i+1}</i><span>${esc(o)}</span><b>${counts[i]||''}</b>${total?`<em style="--w:${Math.round(100*(counts[i]||0)/total)}%"></em>`:''}</button>`).join('')}</div><p class="gut-help">Show 1, 2 or 3 fingers. Tap an option to count hands${round==='after'&&before?` · at the start: ${g.options.map((_,i)=>`${i+1} → ${before[i]||0}`).join(', ')}`:''}. <button class="link-btn" data-gut-reset="${round}">Reset</button></p></div>`;
}
function renderVote(i){
 const q=D.quiz[i],v=state.votes[i]||{},labels='ABCDEF',round=voteStage<2?'r1':'r2',show=voteStage===3;
 const bar=(r,k)=>{const c=v[r]||[],t=c.reduce((x,y)=>x+y,0);return t?`<em class="bar ${r}" style="--w:${Math.round(100*(c[k]||0)/t)}%"><span>${c[k]||0}</span></em>`:'';};
 const steps=['Vote alone','Convince a neighbour · 60 s','Vote again','Reveal'];
 $('#chapter-main').classList.add('vote-page');
 $('#chapter-main').insertAdjacentHTML('beforeend',`<div class="vote"><div class="vote-top"><div><p class="ey">CLASS VOTE · ACT ${i+1} · OBJECTIVE ${D.chapter}.${i+1}</p><h2>${esc(q.q)}</h2></div><ol class="vote-steps">${steps.map((t,k)=>`<li class="${k<voteStage?'done':k===voteStage?'on':''}">${t}</li>`).join('')}</ol></div>
 <div class="vote-options">${q.options.map((o,k)=>`<button class="vote-opt${show&&k===q.answer?' correct':''}${show&&k!==q.answer?' muted':''}" data-vote-opt="${k}" ${voteStage===1||show?'disabled':''}><i>${labels[k]}</i><span>${esc(o)}</span><span class="bars">${bar('r1',k)}${bar('r2',k)}</span></button>`).join('')}</div>
 ${show?`<div class="vote-why"><b>Why</b><p>${esc(q.why)}</p></div>`:voteStage===1?`<div class="vote-why discuss"><b>Find someone who voted differently.</b><p>Convince them in 60 seconds, or let them convince you. Use the case, not the slide wording.</p></div>`:''}
 <div class="actions"><button class="primary" data-vote-next>${voteStage<3?steps[voteStage+1]+' →':'Back to the lecture'}</button>${voteStage!==1&&!show?`<button data-vote-minus>Undo last count</button>`:''}<button data-vote-back>Return to slide</button><span class="small">Tap an option to count raised hands (${round==='r1'?'first':'second'} vote). Practice only: not graded.</span></div></div>`);
}
let buildItems=[],buildAt=0,buildSlide=-1;
// Builds run once per visit: re-rendering the same slide (after a vote, station or national slide) shows everything.
function setupBuilds(){
 buildItems=[];buildAt=0;const again=buildSlide===index;buildSlide=index;
 if(again||!PRESENTER||!STORY||stationMode||voteMode!==null||readingLayout())return;
 buildItems=qa('#chapter-main .body-merged .concept, #chapter-main .meaning .points li');
 if(buildItems.length<2){buildItems=[];return;}
 buildItems.forEach(e=>e.classList.add('build'));
}
function nextBuild(){if(buildAt>=buildItems.length)return false;buildItems[buildAt++].classList.add('built');return true;}
let thinkTimer=null;
function think(b){clearInterval(thinkTimer);let t=Number(b.dataset.think)||30;const show=()=>{b.textContent=t>0?`Think · ${t} s`:'Now compare with a neighbour';};b.classList.remove('done');b.classList.add('running');show();thinkTimer=setInterval(()=>{t--;show();if(t<=0){clearInterval(thinkTimer);thinkTimer=null;b.classList.replace('running','done');}},1000);}
function renderMindMap(){
 const r=D.roadmap;
 $('#chapter-main').classList.add('mindmap-page');
 $('#chapter-main').insertAdjacentHTML('beforeend',`
 <div class="map-question">
   <span>CHAPTER ${D.chapter} · BIG QUESTION</span>
   <h2>${esc(r.question)}</h2>
   <p>${esc(D.case.headline)}</p>
 </div>
 <div class="concept-path" aria-label="Five connected chapter concepts">
   ${r.branches.map((b,i)=>`<button class="map-step" data-jump="${esc(b.target)}" aria-label="${esc(b.label)}. Open the related lesson.">
      <span class="step-number">${i+1}</span>
      <span class="step-verb">${esc(b.verb)}</span>
      <strong>${esc(b.label)}</strong>
      <span class="step-detail">${esc(b.detail)}</span>
      <span class="step-case"><i>In our story</i>${esc(b.caseLens||'Use this concept to narrow the decision.')}</span>${b.aiLens?`<span class="step-lens">AI lens · ${esc(b.aiLens)}</span>`:''}
   </button>`).join('')}
 </div>
 <p class="mind-link"><b>WHY THIS ORDER</b> ${esc(r.connection)}</p>
 <div class="student-roadmap" aria-label="What happens in class and after class">
   <section class="road-stage"><h3><span>01</span> In class</h3><p><b>Instructor:</b> Explain the mechanism and guide three short stations.</p><p><b>You:</b> ${esc(r.inClass)}</p><p class="road-result">One evolving practice card—not several reports.</p></section>
   <section class="road-stage"><h3><span>02</span> Required review</h3><p><b>Instructor:</b> Name the exact source selections.</p><p><b>You:</b> Review source slides ${D.readings.map(x=>esc(x.range)).join(' + ')} and complete the five-objective practice.</p><p class="road-result">Fix misunderstandings before the assignment.</p></section>
   <section class="road-stage"><h3><span>03</span> Assignment ${D.assignment}</h3><p><b>Instructor:</b> Review using the published rubric.</p><p><b>You:</b> ${esc(r.deliverable)}</p><p class="road-result">New case → commit → STRESS → REFIT → Blackboard.</p></section>
 </div>
 <div class="map-bottom"><p><b>REQUIRED:</b> class + named review + assignment. Other tools support the same work unless explicitly assigned.</p><div class="actions">${button('Case connections','CASEMAP')}${jumpButton('START','Start the story →')}</div></div>`);
}
function renderStory(){
 if(STORY){renderCaseFile();return;}
 const r=D.roadmap;
 $('#chapter-main').classList.add('story-page');
 $('#chapter-main').insertAdjacentHTML('beforeend',`
 <div class="story-head"><span>OUR STORY · FICTIONAL TEACHING CASE</span><h2>${esc(D.case.headline)}</h2><p>Keep this same case in mind as every concept is introduced.</p></div>
 <div class="story-grid">
   <section><h3>1 · Situation</h3><p>${esc(D.case.text)}</p></section>
   <section><h3>2 · Your decision</h3><p>${esc(D.case.question)}</p></section>
   <section><h3>3 · Evidence rule</h3><p>Use supplied facts and transparent calculations. Keep missing tests and unknowns visible; do not invent measurements.</p></section>
 </div>
 ${D.case.lens?`<div class="story-lens"><b>AI LENS · ADDED TO THE CASE</b>${esc(D.case.lens)}</div>`:''}
 <div class="story-route" aria-label="How the story will be revisited">
   ${r.branches.map((b,i)=>`<span><b>${i+1}</b>${esc(b.label)}</span>`).join('')}
 </div>
 <div class="story-note"><b>One story, five lenses.</b> Each main slide will show a CASE THREAD that tells you which part of this decision the concept helps you answer. The changed constraint is revealed later—do not guess it now.</div>
 <div class="actions story-action">${jumpButton(r.branches[0].target,'Start learning →')}</div>`);
}
function renderCaseFile(){
 const r=D.roadmap,cast=[SERIES.lead,SERIES.mentor,STORY.client];
 $('#chapter-main').classList.add('story-page','case-file');
 $('#chapter-main').insertAdjacentHTML('beforeend',`
 <div class="story-head"><span>${esc(STORY.episode)} · FICTIONAL TEACHING CASE</span><h2>${esc(D.case.headline)}</h2><p>${esc(STORY.setting)} <b class="clock">⏱ ${esc(STORY.clock)}</b></p></div>
 <div class="cast" aria-label="People in this episode">${cast.map(c=>`<div class="cast-card"><i aria-hidden="true">${esc(c.name.replace(/^Dr\.\s*/,'').charAt(0))}</i><b>${esc(c.name)}</b><span>${esc(c.role)}</span></div>`).join('')}</div>
 <div class="story-grid">
   <section><h3>What we know</h3><p>${esc(D.case.text)}</p></section>
   <section><h3>The decision</h3><p>${esc(D.case.question)}</p></section>
   <section><h3>What is at stake</h3><p>${esc(STORY.stakes)}</p></section>
 </div>
 ${D.case.lens?`<div class="story-lens"><b>AI LENS · ADDED TO THE CASE</b>${esc(D.case.lens)}</div>`:''}
 <div class="story-route" aria-label="Five acts">${r.branches.map((b,i)=>`<span><b>${i+1}</b>${esc(b.label)}</span>`).join('')}</div>
 <div class="story-note"><p><b>One story, five lenses.</b> Five acts, one concept each, with class votes along the way; something changes before the end. Evidence rule: supplied facts and transparent calculations only, and keep unknowns visible.</p><span class="actions story-action">${jumpButton(r.branches[0].target,'Act 1 →')}</span></div>`);
}
function renderClosing(){
 const r=D.roadmap;
 $('#chapter-main').classList.add('end-page');
 $('#chapter-main').insertAdjacentHTML('beforeend',`
 <div class="end-hero"><div class="end-copy">
  <p class="ey">CHAPTER ${D.chapter} · COMPLETE · READINESS</p><h2>${esc(D.title)}</h2>
  ${STORY?`<div class="epilogue"><span>${esc(STORY.episode)} · TO BE CONTINUED IN YOUR ASSIGNMENT</span><p>${esc(STORY.epilogue)}</p></div>${gutBlock('after')}<div class="exit-ticket"><b>Exit ticket · one minute, on paper or Blackboard</b><ol><li>One idea you can now explain to Layan.</li><li>The muddiest point from today.</li><li>Did your vote change? What changed it?</li></ol></div>`:''}
  <p class="end-success">Ready means you can <b>explain, verify and own</b> the decision—not merely repeat the content.</p>
  <div class="readiness-strip" aria-label="Readiness checks"><section><b>Explain</b><span>Use the mechanism without outsourcing the core judgment to AI.</span></section><section><b>Verify</b><span>Use inspectable evidence; label unknowns and any AI assistance.</span></section><section><b>Own</b><span>Revise under changed evidence and name the responsible human role.</span></section></div>
  <div class="end-required"><section><span>1</span><div><b>Required review</b><p>${D.readings.map(x=>esc(x.title)+' · '+esc(x.range)).join(' | ')}</p></div></section><section><span>2</span><div><b>Five-objective check</b><p>Correct misunderstandings before the assessed case.</p></div></section><section><span>3</span><div><b>Assignment ${D.assignment}</b><p>${esc(r.deliverable)} Submit through Blackboard.</p></div></section></div>
  <div class="actions">${button('Preparation & sources','DISCLOSURE')}${button('Open required review','READING','primary')}<a href="https://adeebnoor.github.io/CPIT/fbr-submission.html?chapter=${D.chapter}">Open Assignment ${D.assignment}</a></div>
 </div><img src="${esc(D.brand)}" alt=""></div>`);
}
function nelcAlignment(){
 const r=D.roadmap||{};
 modal('NELC alignment · Chapter '+D.chapter,`
 <div class="nelc-reference"><div class="national-logo"><img src="assets/national/nelc-logo.png" alt="National eLearning Center"></div><div><p class="ey">SAUDI NATIONAL ALIGNMENT · VERSION 1.0 · SEPTEMBER 2026</p><h3 lang="en" dir="ltr">AI-supported Teaching and Learning Design Framework</h3><p>National eLearning Center · Saudi Arabia</p></div></div>
 <div class="callout"><b>Alignment, not endorsement.</b> This chapter operationalizes the framework as a design crosswalk. It does not claim NELC certification, approval or partnership.</div>
 <div class="callout" lang="en" dir="ltr"><b>AI’s purpose in this chapter:</b> ${esc(window.ISCARB_NATIONAL.chapters[D.chapter].ai)}. The learner starts independently, then verifies and discloses any assistance.<br><b>Verification evidence:</b> ${esc(window.ISCARB_NATIONAL.chapters[D.chapter].evidence)}.<br><b>Review criterion:</b> ${esc(window.ISCARB_NATIONAL.chapters[D.chapter].check)}</div><h3>Five design principles → this chapter</h3><div class="nelc-principles"><article><b>1 · Learning first</b><span>Five measurable objectives and named source review come before the AI layer.</span></article><article><b>2 · Clear educational value</b><span>AI is used for transfer, critique, practice or simulation when it adds a defined learning benefit.</span></article><article><b>3 · Human-centered</b><span>The learner explains and decides; the instructor retains educational and professional judgment.</span></article><article><b>4 · Responsible design</b><span>Evidence, uncertainty, disclosure, human review and bounded AI roles stay visible.</span></article><article><b>5 · Evidence-based improvement</b><span>Readiness, transfer and revision evidence matter; output quality alone is not treated as learning.</span></article></div>
 <h3>Six-stage crosswalk</h3><div class="nelc-stages"><article><i>1</i><b>Define</b><span>${D.objectives.length} objectives + observable evidence.</span></article><article><i>2</i><b>Design</b><span>Mind map → story → source-grounded explanation → three stations.</span></article><article><i>3</i><b>Enhance</b><span>AI lens/challenge adds practice after the core concept is established.</span></article><article><i>4</i><b>Distribute roles</b><span>Student reasons; AI supports; instructor validates and judges.</span></article><article><i>5</i><b>Assess</b><span>Independent reasoning, commitment, changed evidence, REFIT and disclosure.</span></article><article><i>6</i><b>Verify & improve</b><span>Readiness check, rubric evidence, feedback and course evaluation inform improvement.</span></article></div>
 <h3>Role boundary in Chapter ${D.chapter}</h3><table class="nelc-roles"><tr><th>Learner</th><th>AI</th><th>Instructor</th></tr><tr><td>Explain the mechanism, make and revise the bounded decision, verify any AI-supported claim.</td><td>Support practice, critique, alternatives or simulation; never become the evidence or final authority by itself.</td><td>Select the source and case, guide practice, sample reasoning and retain final educational judgment.</td></tr></table>
 <p class="small"><b>Chapter design question:</b> ${esc(r.question||D.case?.question||'What must the learner be able to do independently?')}</p>
 <div class="actions"><a class="primary-link" href="../../nelc-alignment.html#chapter-${D.chapter}" target="_blank" rel="noopener">Open full NELC × iSCARB crosswalk ↗</a>${button('Readiness crosswalk','READINESS')}</div>`);
}
function mapObjectives(){
 modal('Five chapter objectives · source outline',`<div class="callout">The mind map groups the existing source concepts for learning. It does not replace the five objectives, original sections or assigned source review.</div><ol class="objective-list">${D.objectives.map((x,i)=>`<li>${esc(x)}${D.objectiveLens?.[i]?`<small class="obj-lens">AI lens · ${esc(D.objectiveLens[i])}</small>`:''}</li>`).join('')}</ol>${D.cs2023?`<h3>International alignment · ACM/IEEE-CS/AAAI CS2023</h3><table class="align"><tr><th>CS2023 unit</th><th>How this chapter addresses it</th></tr>${D.cs2023.map(r=>`<tr><td><b>${esc(r[0])}</b><br><small>${esc(r[1])}</small></td><td>${esc(r[2])}</td></tr>`).join('')}</table><p class="small">Mapped against the CS2023 Software Engineering knowledge-area text and, for other areas, at knowledge-area level. Alignment describes coverage, not accreditation.</p>`:''}<h3>Original chapter spine</h3><ul>${D.sections.map(x=>`<li>${esc(x)}</li>`).join('')}</ul><h3>Check your understanding</h3><p>${esc(D.roadmap.success)}</p><h3>Our fictional classroom case</h3><p>${esc(D.case.text)}</p><p><b>${esc(D.case.question)}</b></p><div class="actions">${jumpButton('MAP','Back to chapter map')}${button('Five-objective practice','QUIZ')}</div>`);
}
function updateMapLocation(){
 const s=D.slides[index],r=D.roadmap,b=r.branches.find(x=>x.units.includes(s.id)),label=$('#topic-location');
 if(label)label.textContent=s.id==='MAP'?'Your overview':s.id==='TITLE'?'Start here':b?b.label:stationMode?'Practice station':'Case and learning path';
 const mapButton=$('#mapBtn');if(mapButton)mapButton.setAttribute('aria-current',s.id==='MAP'?'step':'false');
}

function open(k){k=(D.aliases||{})[k]||k;if(D.slides.some(s=>s.id===k)){jump(k);return;}const aliases={PREP:'QUIZ',C01:'COVERAGE',J01:'READINESS',J02:'QUIZ',AIGATE:'AI',READING:'READING'};k=aliases[k]||k;({UNITS:indexModal,READING:reading,COVERAGE:coverage,RULES:rules,TOOLS:studyTools,OBJECTIVES:mapObjectives,CASEMAP:()=>modal('Five concepts in our case',`<p>${esc(D.case.question)}</p><div class="case-map-details">${D.roadmap.branches.map(b=>`<section><h3>${esc(b.label)}</h3><p>${esc(b.caseLens||'Use this concept to narrow the decision.')}</p>${b.aiLens?`<p>AI lens · ${esc(b.aiLens)}</p>`:''}${jumpButton(b.target,'Open this concept')}</section>`).join('')}</div>`),CARD:card,HSTACK:hstack,PREDICT:predict,BRIDGE:bridge,MONITOR:monitor,LOCAL:local,PRACTICE:practice,WELLBEING:wellbeing,AI:ai,EVIDENCE:evidence,RUBRIC:rubric,READINESS:()=>nationalSlide(0),NELC:()=>nationalSlide(1),DISCLOSURE:()=>modal('Preparation, sources and national alignment',`<p>${esc(D.disclosure||'Source-grounded classroom materials; instructor review remains required.')}</p><p>National alignment: learning outcomes first; bounded AI assistance; accountable human judgment; improvement from evidence.</p><div class="actions">${button('Jaheziah readiness','READINESS')}${button('NELC alignment','NELC')}${button('Source coverage','COVERAGE')}</div>`),READINESSDETAIL:readiness,NELCDETAIL:nelcAlignment,'NATIONAL-JAHEZIAH':()=>nationalSlide(0),'NATIONAL-NELC':()=>nationalSlide(1),PORTFOLIO:portfolio,QUIZ:quiz,CALCULATOR:calculator,HELP:help,NOTES:notes,AIASSIGN:aiChallenge}[k]||(()=>modal('Source or tool',`<p>This earlier unit is available in the complete source review.</p><a href="sources/Ch${D.chapter}-Study.html">Open the source ledger</a>`)))();}
function readable(){return [`# Chapter ${D.chapter}: ${D.title}`,'Professor Adeeb Noor · CPIT-455',`Release ${D.release}`,'Fictional teaching case. Student draft; not a grade, submission or certification.','',...Object.entries(state.fields).flatMap(([k,v])=>['## '+(labels[k]||k),v||'[not entered]','']),'## AI gate',aiVerdict(state.ai)].join('\n');}
function download(text,name,type){const u=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),10000);}
function sanitize(p){if(!p||p.schema!=='iscarb-classroom-v3'||p.chapter!==D.chapter||!p.state)throw Error('This backup belongs to a different chapter or format.');let x=p.state,st={fields:{},seen:[],quiz:{},ai:{},self:{},votes:{},gut:{},theme:x.theme==='day'?'day':'night'};for(const [k,v]of Object.entries(x.fields||{})){if(!validField(k)||typeof v!=='string'||v.length>15000)throw Error('Invalid text field.');st.fields[k]=v;}for(const [k,v]of Object.entries(x.quiz||{})){if(!/^[0-4]$/.test(k)||!v||!Number.isInteger(v.answer)||v.answer<0||v.answer>=D.quiz[k].options.length)throw Error('Invalid quiz record.');st.quiz[k]={answer:v.answer,checked:!!v.checked};}for(const[k,v]of Object.entries(x.ai||{})){if(!/^[0-3]$/.test(k)||!['yes','no'].includes(v))throw Error('Invalid AI record.');st.ai[k]=v;}st.seen=(Array.isArray(x.seen)?x.seen:[]).filter(k=>D.slides.some(s=>s.id===k));const counts=(a,n)=>Array.isArray(a)&&a.length===n&&a.every(c=>Number.isInteger(c)&&c>=0&&c<=999);for(const[k,v]of Object.entries(x.votes||{})){if(/^[0-4]$/.test(k)&&D.quiz[k]&&v&&['r1','r2'].every(r=>v[r]===undefined||counts(v[r],D.quiz[k].options.length)))st.votes[k]={r1:v.r1,r2:v.r2};}const g=STORY?.gut?.options?.length||0;for(const r of['before','after'])if(g&&counts(x.gut?.[r],g))st.gut[r]=x.gut[r];return {state:st};}
async function restore(file){try{if(file.size>1000000)throw Error('Backup is too large.');const p=sanitize(JSON.parse(await file.text()));if(!confirm('Replace this chapter’s current classroom draft with the imported backup? Assignment work will not change.'))return;state=p.state;save();render();card();}catch(e){modal('Import did not complete',`<p>${esc(e.message)}</p><p>Your existing draft was not changed.</p>`);}}
/* ===== iSCARB GenAI edition additions (v11): tool tiles + embedded AI challenge ===== */
const ICON={
 CARD:'<path d="M5 4h11l3 3v13H5z"/><path d="M8 11h8M8 15h6"/>',
 OBJECTIVES:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',
 NOTES:'<path d="M4 5h16v11H9l-5 4z"/>',
 CALCULATOR:'<rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 7h6M9 12h1M14 12h1M9 16h1M14 16h1"/>',
 READING:'<path d="M3 5h7a2 2 0 0 1 2 2v12a2 2 0 0 0-2-2H3zM21 5h-7a2 2 0 0 0-2 2v12a2 2 0 0 1 2-2h7z"/>',
 QUIZ:'<path d="M9 9a3 3 0 1 1 4 2.8c-.7.3-1 .8-1 1.5V14"/><circle cx="12" cy="18" r=".6"/><circle cx="12" cy="12" r="9"/>',
 ASSIGN:'<path d="M9 4h6v3H9z"/><path d="M7 5H5v16h14V5h-2"/><path d="M9 13l2 2 4-4"/>',
 PORTFOLIO:'<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V4h6v3M3 12h18"/>',
 RULES:'<path d="M5 6h14M5 12h14M5 18h9"/><circle cx="3" cy="6" r=".6"/><circle cx="3" cy="12" r=".6"/><circle cx="3" cy="18" r=".6"/>',
 COVERAGE:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
 READINESS:'<path d="M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7z"/><path d="M9 12l2 2 4-4"/>',
 AI:'<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
 AIASSIGN:'<path d="M12 2l2.4 5.6L20 10l-5.6 2.4L12 18l-2.4-5.6L4 10l5.6-2.4z"/><path d="M19 17l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>',
 NELC:'<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z"/>',
 HELP:'<circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/>',
 DEFAULT:'<circle cx="12" cy="12" r="8"/><path d="M12 8v8M8 12h8"/>'
};
function icon(k){return `<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICON[k]||ICON.DEFAULT}</svg>`;}
function tile(title,desc,k,cls=''){return `<button class="tile ${cls}" data-open="${esc(k)}"><span class="ti">${icon(k)}</span><span class="tt"><b>${esc(title)}</b><small>${esc(desc)}</small></span></button>`;}
function tileLink(title,desc,href,k,cls=''){return `<a class="tile ${cls}" href="${esc(href)}"><span class="ti">${icon(k)}</span><span class="tt"><b>${esc(title)}</b><small>${esc(desc)}</small></span></a>`;}
const MORE_DESC={HSTACK:'Layer the human and technical checks',PREDICT:'Commit a prediction before the evidence',BRIDGE:'Annotate how the idea is implemented',MONITOR:'Sort known, unknown and what to watch',LOCAL:'Saudi and regional context',PRACTICE:'How industry does this today',WELLBEING:'Sustainable engineering practice',EVIDENCE:'What counts as honest evidence',RUBRIC:'Four-level rubric used in this course'};
function studyTools(){
 const A=D.aiAssignment;
 modal('Study & tools',`${A?`<button class="tile tile-feature" data-open="AIASSIGN"><span class="ti">${icon('AIASSIGN')}</span><span class="tt"><em>AI challenge · Chapter ${D.chapter}</em><b>${esc(A.title)}</b><small>Same topic, new AI case · commit first, then face the change</small></span><span class="go">Start →</span></button>`:''}
 <div class="study-groups">
 <section class="grp grp-class"><h3><span>1</span>In class · one practice card</h3><div class="tiles">
  ${tile('Decision card','Your evolving claim, evidence and verdict · save a backup','CARD')}
  ${tile('Objectives & alignment','Five objectives, source spine and CS2023 alignment','OBJECTIVES')}
  ${PRESENTER?tile('Instructor notes','Teaching notes for the current slide · presenter mode','NOTES'):''}
  ${D.chapter===11?tile('Reliability calculator','POFOD, ROCOF and availability','CALCULATOR'):''}
 </div></section>
 <section class="grp grp-req"><h3><span>2</span>Required after class</h3><div class="tiles">
  ${tile('Required self-study','Named source slides to review','READING')}
  ${tile('Five-objective practice','One question per objective · attempt first','QUIZ')}
  ${tileLink('Assignment '+D.assignment,'Separate case · '+D.points+' points · Blackboard','https://adeebnoor.github.io/CPIT/fbr-submission.html?chapter='+D.chapter,'ASSIGN','tile-req')}
  ${tile('Assignment workflow','Artifact, commit/reveal and rubric','PORTFOLIO')}
 </div><p class="small">Blackboard gives dates and confirms submission. A local draft is not submitted work.</p></section>
 <section class="grp grp-src"><h3><span>3</span>Sources, methodology & support</h3><div class="tiles">
  ${tile('20 iSCARB rules','The method behind every slide','RULES')}
  ${tile('Source coverage','Which source slide feeds which lesson','COVERAGE')}
  ${tile('NCAAA / Jaheziah','Outcome and readiness crosswalk','READINESS')}
  ${tile('NELC alignment','Saudi AI-supported teaching & learning design framework','NELC')}
  ${tile('AI use & checking','Permissibility gate and disclosure','AI')}
 </div><details class="tool-details"><summary>More iSCARB tools · use when relevant or assigned</summary><div class="tiles">${['HSTACK','PREDICT','BRIDGE','MONITOR','LOCAL','PRACTICE','WELLBEING','EVIDENCE','RUBRIC'].map(k=>tile(titleOf(k),MORE_DESC[k]||'',k)).join('')}</div></details></section>
 <section class="grp grp-disp"><h3><span>4</span>Display</h3><div class="actions"><button id="themeBtn">Day / night</button><button id="fullBtn">Fullscreen</button>${button('Navigation and saving help','HELP')}</div></section></div>`);
}
const AIX=['aix_fit','aix_bound','aix_act','aix_evidence'];
const AIX_LABEL={aix_fit:'FIT · what fits now, and why',aix_bound:'BOUND · the observable condition where it stops fitting',aix_act:'ACT · the concrete engineering action',aix_evidence:'EVIDENCE · what another engineer could inspect',aix_ai:'AI DECLARATION · tools used, what you checked yourself',aix_refit:'REFIT · justify your verdict using the new information',aix_owner:'OWNER · who accepts the residual risk, and who must be told'};
function aixField(k,ph,locked){const v=state.fields[k]||'';return `<label class="field ${locked?'locked':''}"><span>${esc(AIX_LABEL[k])}</span><textarea data-field="${esc(k)}" maxlength="6000" placeholder="${esc(ph||'')}" ${locked?'readonly':''}>${esc(v)}</textarea></label>`;}
function aixWords(){return AIX.map(k=>(state.fields[k]||'').trim().split(/\s+/).filter(Boolean).length).reduce((a,b)=>a+b,0);}
function aixReady(){return AIX.every(k=>(state.fields[k]||'').trim().length>=20);}
function aixText(){const A=D.aiAssignment,f=state.fields;return [`# CPIT-455 · Chapter ${D.chapter} · AI challenge`,`## ${A.title}`,`Committed: ${f.aix_commit||'not committed'}`,'',`### Scenario`,A.scenario,'',...AIX.map(k=>`### ${AIX_LABEL[k]}\n${f[k]||''}`),'',`### ${AIX_LABEL.aix_ai}\n${f.aix_ai||''}`,'',`### STRESS`,f.aix_commit?A.stress:'(revealed after commitment)','',`### Verdict: ${f.aix_verdict||'—'}`,`### ${AIX_LABEL.aix_refit}\n${f.aix_refit||''}`,`### ${AIX_LABEL.aix_owner}\n${f.aix_owner||''}`,'',`Words in FIT–EVIDENCE: ${aixWords()} (target ${A.words||'180–260'})`].join('\n');}
function aiChallenge(){
 const A=D.aiAssignment;if(!A){modal('AI challenge','<p>No AI challenge is defined for this chapter.</p>');return;}
 const f=state.fields,locked=!!f.aix_commit;
 modal('AI challenge · Chapter '+D.chapter,`<div class="aix-head"><span class="ai-tag">AI</span><b>${esc(A.title)}</b><span class="aix-badge">Same topic · new case · practice unless your instructor assigns it</span></div>
 <div class="aix-case"><h3>Scenario</h3><p>${esc(A.scenario)}</p><ul>${(A.facts||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul><p class="aix-q"><b>Your decision:</b> ${esc(A.question)}</p></div>
 <ol class="aix-steps"><li class="${locked?'done':'on'}">Decide</li><li class="${locked?'done':''}">Commit</li><li class="${locked?'on':''}">Face the change</li><li class="${f.aix_verdict?'done':''}">Revise & own</li></ol>
 <div class="two-col">${aixField('aix_fit',A.hints?.fit,locked)}${aixField('aix_bound',A.hints?.bound,locked)}${aixField('aix_act',A.hints?.act,locked)}${aixField('aix_evidence',A.hints?.evidence,locked)}</div>
 <p class="small" id="aix-count">Words in FIT–EVIDENCE: ${aixWords()} · target ${esc(A.words||'180–260')}</p>
 ${aixField('aix_ai','None, or: which tool, for what, and how you checked its output independently.',false)}
 ${locked?`<div class="aix-stress"><h3>New information · ${esc(f.aix_commit)}</h3><p>${esc(A.stress)}</p></div>
  <div class="aix-verdict" role="group" aria-label="Verdict">${['Retain','Revise','Replace'].map(v=>`<button data-aix-verdict="${v}" aria-pressed="${f.aix_verdict===v}">${v}</button>`).join('')}</div>
  <div class="two-col">${aixField('aix_refit','Name the assumption the new information broke.',false)}${aixField('aix_owner','A role and a scope, never “the system”.',false)}</div>`
 :`<div class="actions"><button id="aix-commit" class="primary" ${aixReady()?'':'disabled'}>Commit and reveal the change</button><span class="small">Commit locks FIT–EVIDENCE so your first reasoning is preserved. Each field needs a sentence first.</span></div>`}
 <details class="tool-details"><summary>How this is judged · rubric</summary><table><tr><th>Criterion</th><th>Strong</th><th>Developing</th></tr>${(A.rubric||AIX_RUBRIC).map(r=>`<tr><td><b>${esc(r[0])}</b></td><td>${esc(r[1])}</td><td>${esc(r[2])}</td></tr>`).join('')}</table><p class="small">${esc(A.framing||'Changing your mind with specific counter-evidence is rewarded; a lucky first answer is not.')}</p></details>
 <div class="actions"><button id="aix-copy">Copy submission</button><button id="aix-download">Download .md</button><button id="aix-reset">Reset challenge</button></div>
 <p class="status" data-save-status></p><p class="small">Saved on this device only. Submit through Blackboard only if your instructor assigns this challenge.</p>`);
}
const AIX_RUBRIC=[
 ['Fit','Uses a named chapter concept to justify the choice for this AI case.','Names a concept but does not connect it to the case.'],
 ['Bound','States an observable condition that would end the claim.','Boundary is vague (“if it fails”).'],
 ['Evidence','Inspectable evidence that stays valid even if the AI component is wrong.','Relies on the AI’s own output or a vendor claim.'],
 ['Revision','Verdict uses the specific new information and names the broken assumption.','Repeats the first answer or changes it without reason.'],
 ['Ownership & AI use','Names a role and scope; declares any AI assistance and how it was checked.','No owner, or undeclared assistance.']];
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
 if(b.id==='aix-commit'){if(!aixReady())return;state.fields.aix_commit=new Date().toLocaleString();save();aiChallenge();return;}
 if(b.dataset.aixVerdict){state.fields.aix_verdict=b.dataset.aixVerdict;save();aiChallenge();return;}
 if(b.id==='aix-copy'){const t=aixText();(navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(()=>{b.textContent='Copied ✓';},()=>{b.textContent='Copy blocked · use Download';});return;}
 if(b.id==='aix-download'){download(aixText(),`Ch${D.chapter}-AI-challenge.md`,'text/markdown');return;}
 if(b.id==='aix-reset'){if(!confirm('Clear this AI challenge, including the committed answer?'))return;[...AIX,'aix_ai','aix_refit','aix_owner','aix_verdict','aix_commit'].forEach(k=>delete state.fields[k]);save();aiChallenge();return;}
});
document.addEventListener('input',e=>{const k=e.target.dataset.field;if(k&&k.startsWith('aix_')&&validField(k)){state.fields[k]=e.target.value;const c=document.getElementById('aix-count');if(c)c.textContent=`Words in FIT–EVIDENCE: ${aixWords()} · target ${(D.aiAssignment&&D.aiAssignment.words)||'180–260'}`;const btn=document.getElementById('aix-commit');if(btn)btn.disabled=!aixReady();}});
document.addEventListener('input',e=>{const k=e.target.dataset.field;if(k&&validField(k)){state.fields[k]=e.target.value;save();}});
document.addEventListener('change',e=>{if(e.target.name==='quiz'){state.quiz[quizIndex]={answer:Number(e.target.value),checked:false};save();$('#quiz-feedback').hidden=true;}});
document.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;if(b.hasAttribute('data-national-return')){go(index);return;}if(b.dataset.vectorTab!==undefined){qa('[data-vector-pane]').forEach(x=>x.hidden=x.dataset.vectorPane!==b.dataset.vectorTab);qa('[data-vector-tab]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));return;}if(b.dataset.open){open(b.dataset.open);return;}if(b.dataset.jump){jump(b.dataset.jump);return;}if(b.dataset.go!==undefined){closeModal();go(Number(b.dataset.go));return;}if(b.dataset.full){full(b.dataset.full);return;}if(b.dataset.answer){answer(b.dataset.answer);return;}if(b.dataset.image){modal(b.dataset.caption||'Preserved source figure',`<div class="source-original ${b.dataset.vector?'source-vector-expanded':''}"><img class="zoom-figure source-natural" src="${esc(b.dataset.image)}" alt="${esc(b.dataset.caption)}"><p class="small"><b>Original source figure.</b> Vector figures retain the source labels and relationships at any zoom. Consult the source pack for the surrounding explanation and assumptions.</p></div>`);return;}if(b.dataset.quiz!==undefined){quizIndex=Number(b.dataset.quiz);quiz();return;}if(b.dataset.ai!==undefined){state.ai[b.dataset.ai]=b.dataset.value;save();qa('[data-ai="'+b.dataset.ai+'"]').forEach(x=>x.setAttribute('aria-pressed',String(x.dataset.value===b.dataset.value)));$('#ai-result').textContent=aiVerdict(state.ai);return;}if(b.dataset.export){download(b.dataset.export==='json'?JSON.stringify(pack(),null,2):readable(),`Ch${D.chapter}-classroom-${b.dataset.export==='json'?'backup.json':'card.md'}`,b.dataset.export==='json'?'application/json':'text/markdown');return;}
switch(b.id){case 'prevBtn':advanceSection(-1);break;case 'nextBtn':advanceSection(1);break;case 'modal-close':closeModal();break;case 'stationBtn':stationMode=true;render();break;case 'station-back':pauseTimer();stationMode=false;render();break;case 'timer-start':startTimer();break;case 'timer-reset':pauseTimer();remaining=180;timerLabel();break;case 'hintBtn':{const st=D.stations.find(x=>x.no===Number(b.dataset.no));$('#coach').innerHTML='<b>Authored hint.</b> '+esc(st.hint);break;}case 'station-answer':{const st=D.stations.find(x=>x.no===Number(b.dataset.no));modal('Station discussion · illustrative reasoning',`<p>${esc(st.answer)}</p><p class="small">Check the mechanism and assumptions. This is not an answer to the separately assessed case.</p>`);break;}case 'quiz-check':if(state.quiz[quizIndex]?.answer===undefined){$('#quiz-feedback').hidden=false;$('#quiz-feedback').textContent='Choose an answer before opening feedback.';}else{state.quiz[quizIndex].checked=true;save();quizFeedback();}break;case 'calculate':compute();break;case 'import':{const i=document.createElement('input');i.type='file';i.accept='.json,application/json';i.onchange=()=>i.files[0]&&restore(i.files[0]);i.click();break;}case 'clear':if(confirm('Clear this chapter’s classroom draft? Export a backup first. Assignment work will not change.')){state.fields={};state.quiz={};state.ai={};save();card();}break;case 'copy':try{await navigator.clipboard.writeText(readable());$('#live').textContent='Card copied.';}catch(e){download(readable(),`Ch${D.chapter}-card.md`,'text/markdown');}break;case 'viewBtn':document.body.classList.toggle('reading');b.setAttribute('aria-pressed',String(document.body.classList.contains('reading')));b.textContent=document.body.classList.contains('reading')?'Presentation':'Reading view';if(sectionNodes.length)showSection(sectionIndex);break;case 'themeBtn':state.theme=state.theme==='day'?'night':'day';try{localStorage.setItem('iscarb-theme',state.theme==='day'?'light':'dark')}catch(e){}document.body.classList.toggle('day',state.theme==='day');save();break;case 'fullBtn':try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch(e){$('#live').textContent='Fullscreen was not allowed; normal and reading views remain available.';}break;case 'notesBtn':notes();break;case 'helpBtn':help();break;}
});
document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
 if(b.hasAttribute('data-pace-reset')){try{sessionStorage.setItem(paceKey,String(Date.now()-(index?PLAN.end[index-1]:0)*60000));}catch(e){}b.outerHTML=paceChip();return;}
 if(b.dataset.think){think(b);return;}
 if(b.dataset.vote!==undefined){voteMode=Number(b.dataset.vote);voteStage=0;render();$('#chapter-main').scrollTo?.(0,0);return;}
 if(b.dataset.voteOpt!==undefined&&voteMode!==null){const q=D.quiz[voteMode],r=voteStage<2?'r1':'r2',v=state.votes[voteMode]=state.votes[voteMode]||{};v[r]=v[r]||q.options.map(()=>0);v[r][Number(b.dataset.voteOpt)]=Math.min(999,v[r][Number(b.dataset.voteOpt)]+1);v.last=Number(b.dataset.voteOpt);save();render();return;}
 if(b.hasAttribute('data-vote-minus')&&voteMode!==null){const v=state.votes[voteMode],r=voteStage<2?'r1':'r2';if(v?.[r]&&v.last!==undefined&&v[r][v.last]>0){v[r][v.last]--;save();render();}return;}
 if(b.hasAttribute('data-vote-next')){if(voteStage<3){voteStage++;render();}else{voteMode=null;voteStage=0;render();}return;}
 if(b.hasAttribute('data-vote-back')){voteMode=null;voteStage=0;render();return;}
 if(b.dataset.gut){const g=STORY.gut,r=b.dataset.gut;state.gut[r]=state.gut[r]||g.options.map(()=>0);const k=Number(b.dataset.opt);state.gut[r][k]=Math.min(999,state.gut[r][k]+1);save();b.closest('.gut').outerHTML=gutBlock(r);return;}
 if(b.dataset.gutReset){delete state.gut[b.dataset.gutReset];save();b.closest('.gut').outerHTML=gutBlock(b.dataset.gutReset);return;}
 if(b.hasAttribute('data-twist-reveal')){const p=b.closest('[data-twist-panel]');p.querySelector('.twist-commit').hidden=true;p.querySelector('.twist-scene').hidden=false;$('#chapter-main').classList.remove('twist-locked');$('#live').textContent='New information revealed.';return;}
});
$('#modal').addEventListener('click',e=>{if(e.target===$('#modal'))closeModal();});

// Navigation v1: native controls/editing win over presentation shortcuts.
const navControl='input,textarea,select,button,a[href],label,summary,audio,video,iframe,[role="button"],[role="textbox"],[role="combobox"],[role="slider"],[data-no-slide-nav]';
function navInteractive(target){return !(target instanceof Element)||target.isContentEditable||!!target.closest(navControl);}
function selectedText(){const s=window.getSelection();return !!(s&&!s.isCollapsed);}
function mousePresentation(){return !stationMode&&$('#modal').hidden&&!document.body.classList.contains('reading')&&matchMedia('(min-width:1001px)').matches;}
let navPointer=null,lastMouseSlide=-Infinity;
$('#chapter-main').addEventListener('pointerdown',e=>{
 navPointer=null;
 if(e.pointerType!=='mouse'||e.button!==0||e.ctrlKey||e.altKey||e.metaKey||!mousePresentation()||navInteractive(e.target))return;
 navPointer={x:e.clientX,y:e.clientY,index,selected:selectedText()};
});
$('#chapter-main').addEventListener('pointercancel',()=>{navPointer=null;});
$('#chapter-main').addEventListener('click',e=>{
 const p=navPointer;navPointer=null;
 if(!p||e.defaultPrevented||e.button!==0||e.detail!==1||e.ctrlKey||e.altKey||e.metaKey||!mousePresentation()||navInteractive(e.target))return;
 if(p.index!==index||p.selected||selectedText()||Math.hypot(e.clientX-p.x,e.clientY-p.y)>8||performance.now()-lastMouseSlide<260)return;
 lastMouseSlide=performance.now();e.preventDefault();advanceSection(e.shiftKey?-1:1);
});
$('#prevBtn').title='Previous slide · Backspace or Left arrow';
$('#nextBtn').title='Next slide · Enter or Right arrow';
$('#chapter-main').setAttribute('aria-keyshortcuts','Enter Backspace ArrowLeft ArrowRight Home End');

document.addEventListener('keydown',e=>{if(e.defaultPrevented||e.isComposing||e.ctrlKey||e.altKey||e.metaKey)return;if(!$('#modal').hidden){if(e.key==='Escape'){e.preventDefault();closeModal();}if(e.key==='Tab'){const a=qa('.dialog button,.dialog input,.dialog textarea,.dialog select,.dialog a[href]').filter(x=>!x.disabled&&x.getClientRects().length);if(a.length){if(e.shiftKey&&document.activeElement===a[0]){e.preventDefault();a.at(-1).focus();}else if(!e.shiftKey&&document.activeElement===a.at(-1)){e.preventDefault();a[0].focus();}}}return;}if(nationalIndex!==null&&e.key==='Escape'){e.preventDefault();go(index);return;}if(navInteractive(e.target))return;if(e.key==='Enter'||e.key==='Backspace'){if(e.shiftKey)return;e.preventDefault();if(!e.repeat)advanceSection(e.key==='Enter'?1:-1);return;}if(e.key==='ArrowRight'){e.preventDefault();advanceSection(1);}else if(e.key==='ArrowLeft'){e.preventDefault();advanceSection(-1);}else if(e.key==='Home'){e.preventDefault();go(0);}else if(e.key==='End'){e.preventDefault();go(D.slides.length-1);}else if(e.key.toLowerCase()==='o')indexModal();else if(e.key.toLowerCase()==='c')card();else if(e.key.toLowerCase()==='n'&&PRESENTER)notes();});
try{state.theme=localStorage.getItem('iscarb-theme')==='dark'?'night':'day'}catch(e){state.theme='day'}
document.body.classList.toggle('day',state.theme==='day');const hash=location.hash.slice(1);const initial=D.slides.findIndex(s=>s.id===hash);go(initial>=0?initial:0,false);if(hash&&initial<0)open(hash);
window.iscarb={data:D,go,open,jump,full,answer,closeModal,aiVerdict,pack,sanitize,compute,getState:()=>JSON.parse(JSON.stringify(state)),getIndex:()=>index,startStation:no=>{const st=D.stations.find(s=>s.no===no);if(st){go(D.slides.findIndex(s=>s.id===st.at));stationMode=true;render();}},restore};
})();
