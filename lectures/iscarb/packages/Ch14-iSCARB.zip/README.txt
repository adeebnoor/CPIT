iSCARB Chapter 14 / Resilience Engineering
Release 20260921-classroom-v3

Extract the complete ZIP before opening START-HERE.html. Do not move the lecture out of its folders. Classroom, source review, figures and tools run locally. The live course and assignment gateway require internet access.

Classroom drafts stay in your browser when supported. Export your work JSON before changing computers. Previous-lecture draft recovery is retained. This package does not contain or transfer other students' data, marks or assessment submissions.

Source material remains the supplied Sommerville chapter. Any historical examples, numerical discrepancies and course-created scenarios are labelled in the lecture/source review. Official NCAAA/Jaheziah mapping is not certified by this package.

Navigation: Enter = next; Backspace = previous. In desktop presentation mode, click slide content = next; Shift + click = previous. Editing fields, dialogs and controls keep their normal behavior.

Mind-map update: 20260921-mindmap-v1. Open START-HERE.html: cover, then the chapter mind map and student roadmap. Chapter map / Slides / Study & tools replace the crowded toolbar. Source reading and assessments are unchanged.

Story-led classroom update: 20260922-story-v2. Open START-HERE.html. The sequence is cover, concept map, fictional story, lesson, explicit Chapter complete slide.
