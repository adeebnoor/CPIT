iSCARB Chapter 16 / Component-Based Software Engineering
Release 20260921-classroom-v3

Extract the complete ZIP before opening START-HERE.html. Do not move the lecture out of its folders. Classroom, source review, figures and tools run locally. The live course and assignment gateway require internet access.

Classroom drafts stay in your browser when supported. Export your work JSON before changing computers. Previous-lecture draft recovery is retained. This package does not contain or transfer other students' data, marks or assessment submissions.

Source material remains the supplied Sommerville chapter. Any historical examples, numerical discrepancies and course-created scenarios are labelled in the lecture/source review. Official NCAAA/Jaheziah mapping is not certified by this package.

Navigation: Enter = next; Backspace = previous. In desktop presentation mode, click slide content = next; Shift + click = previous. Editing fields, dialogs and controls keep their normal behavior.

Mind-map update: 20260921-mindmap-v1. Open START-HERE.html: cover, then the chapter mind map and student roadmap. Chapter map / Slides / Study & tools replace the crowded toolbar. Source reading and assessments are unchanged.

Story-led classroom update: 20260922-story-v2. Open START-HERE.html. The sequence is cover, concept map, fictional story, lesson, explicit Chapter complete slide.

Student-submission alignment: 20260922-student-submit-v1. The 20 iSCARB rules remain available; evidence/accountability/bounded-decision discipline is embedded in the normal classroom path. Assignment 1/2 identities and hidden STRESS are unchanged.

GenAI edition 20260926-genai-v12. The iSCARB identity is unchanged and the chapter stays at 20 slides. The validation and Ariane slides are merged (both practice questions on the slide). One course-added slide, 'Write the contract for an AI component', uses a contract-writing format and the GenAI visual style. The case, Stations 1-3 and the classroom mutation mention the AI component; a small AI marker flags those prompts. The final revise slide uses four steps (New information → Reassess → Revise → Own) with a one-line principle. The instructor's AI-preparation disclosure appears on the closing slide. Station prompts add a device-free think step, arguing the rejected option, and naming what the first card got wrong. No objective, reading, quiz item, points or assignment changed. Uses the shared runtime 20260926-genai-v12 (backward compatible). Revision v11: the title slide opens with an AI hook; Study & tools uses illustrated tiles; an embedded AI challenge (same topic, new AI case) follows the FIT–BOUND–ACT–EVIDENCE → commit → STRESS → REFIT sequence with AI declaration, rubric, copy and download. It is practice unless the instructor assigns it; the official assignment is unchanged. Revision v12: the objectives panel adds a CS2023 (ACM/IEEE-CS/AAAI) alignment table for the chapter.
